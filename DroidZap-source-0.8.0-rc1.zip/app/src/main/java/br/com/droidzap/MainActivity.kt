package br.com.droidzap

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.database.Cursor
import android.provider.ContactsContract
import android.view.accessibility.AccessibilityEvent
import androidx.appcompat.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.RingtoneManager
import android.net.Uri
import android.text.InputType
import android.view.View
import android.view.MotionEvent
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var prefs: Preferences
    private lateinit var protocol: ProtocolGateway
    private var onHomeScreen = true
    private val voiceRecorder by lazy { VoiceRecorder(this) }
    private val updates by lazy { UpdateManager(this) }
    private var recordedVoice: VoiceRecorder.Result? = null
    private var messageLog: LinearLayout? = null
    private var pendingRecordAction: (() -> Unit)? = null
    private var qrImage: ImageView? = null
    private var activityStatus: TextView? = null
    private var homeConnectionStatus: TextView? = null
    private var pendingContactsAction: (() -> Unit)? = null
    private var activeChatJid: String? = null
    private enum class RingtoneTarget { PRIVATE, GROUP }
    private var ringtoneTarget = RingtoneTarget.PRIVATE
    private val recentChats = linkedMapOf<String, String>()
    private val activeChatCues = mutableSetOf<String>()
    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingRecordAction?.invoke() else announce("Permissão do microfone negada")
        pendingRecordAction = null
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingContactsAction?.invoke() else announce("Permissão para acessar contatos negada")
        pendingContactsAction = null
    }
    private val ringtonePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        @Suppress("DEPRECATION")
        val selected = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        val value = selected?.toString().orEmpty()
        if (ringtoneTarget == RingtoneTarget.PRIVATE) prefs.privateRingtoneUri = value
        else prefs.groupRingtoneUri = value
        showNotificationSettings()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        prefs = Preferences(this)
        protocol = NativeProtocolGateway(this)
        protocol.observeState { state -> runOnUiThread {
            val label = stateLabel(state)
            homeConnectionStatus?.text = "Conexão: $label"
            homeConnectionStatus?.contentDescription = "Estado da conexão: $label"
        } }
        protocol.observeMessages { incoming ->
            runOnUiThread {
                val jid = incoming.chatJid.ifBlank { incoming.senderJid }
                val label = incoming.chatName.ifBlank {
                    contactNameForJid(jid) ?: incoming.senderName.ifBlank { jid.substringBefore('@') }
                }
                recentChats[jid] = label
                val author = if (incoming.isGroup) incoming.senderName.ifBlank { "Participante" } else label
                if (activeChatJid == jid) appendMessage("$author: ${incoming.text.ifBlank { "conteúdo não textual" }}")
                playSystemRingtone(if (incoming.isGroup) prefs.groupRingtoneUri else prefs.privateRingtoneUri)
                vibrateCue()
            }
        }
        protocol.observeChatActivity { _, sender, activity, active ->
            runOnUiThread {
                val person = sender.substringBefore('@').ifBlank { "Contato" }
                val message = when {
                    !active -> ""
                    activity == "recording" -> "$person está gravando áudio"
                    else -> "$person está digitando"
                }
                activityStatus?.text = message
                activityStatus?.contentDescription = message
                val cueKey = "$sender:$activity"
                if (!active) activeChatCues.remove(cueKey)
                else if (activeChatCues.add(cueKey)) {
                    vibrateCue()
                }
            }
        }
        onBackPressedDispatcher.addCallback(this) { if (onHomeScreen) finish() else showHome() }
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 22f; contentDescription = title
                setTextColor(Color.rgb(0, 105, 86))
                setPadding(12, 16, 12, 20)
                isAccessibilityHeading = true
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; contentDescription = label; setOnClickListener { action() }
    }

    private fun showHome() {
        onHomeScreen = true
        activeChatJid = null
        base("Droid Zap")
        homeConnectionStatus = TextView(this).apply {
            text = "Conexão: ${stateLabel(protocol.currentState())}"
            contentDescription = "Estado da conexão: ${stateLabel(protocol.currentState())}"
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(homeConnectionStatus)
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(button("Conversas") { showConversations() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(button("Configurações") { showSettings() }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        if (recentChats.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "Nenhuma conversa nesta sessão"
                contentDescription = text
            })
        } else {
            root.addView(TextView(this).apply {
                text = "Conversas recentes"
                contentDescription = text
                isAccessibilityHeading = true
            })
            recentChats.forEach { (jid, name) ->
                root.addView(button("Abrir conversa com $name") { showChat(name, jid) })
            }
        }
        root.addView(button("Nova conversa") { requestContacts { showNewConversation() } })
        root.addView(button("Parear aparelho") { showPairing() })
        root.addView(button("Procurar atualização") { checkForUpdate() })
        root.addView(button("Diagnóstico e relatório de conexão") { showDiagnostics() })
    }

    private fun showDiagnostics() {
        onHomeScreen = false
        base("Diagnóstico e relatório de conexão")
        val diagnostics = DiagnosticsStore(this)
        val report = TextView(this).apply {
            text = diagnostics.text()
            contentDescription = "Relatório de diagnóstico. $text"
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(report)
        root.addView(button("Copiar relatório") {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Relatório do Droid Zap", report.text))
            announce("Relatório copiado")
        })
        root.addView(button("Apagar relatório") {
            diagnostics.clear(); report.text = "Nenhum evento registrado"
            announce("Relatório apagado")
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun checkForUpdate() {
        announce("Procurando atualização")
        val current = packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0"
        updates.check(current) { result -> runOnUiThread {
            result.onFailure { announce("Não foi possível procurar atualização: ${it.message}") }
                .onSuccess { release ->
                    if (release == null) announce("O Droid Zap já está atualizado")
                    else AlertDialog.Builder(this)
                        .setTitle("Atualização disponível")
                        .setMessage("Versão ${release.version}. Deseja baixar e abrir o instalador?")
                        .setPositiveButton("Baixar") { _, _ -> updates.downloadAndInstall(release, ::announce) }
                        .setNegativeButton("Agora não", null)
                        .show()
                }
        } }
    }

    private fun showConversations() {
        showHome()
    }

    private fun requestContacts(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) action()
        else {
            pendingContactsAction = action
            contactsPermission.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private data class DeviceContact(val name: String, val number: String)

    private fun readContacts(): List<DeviceContact> {
        val result = linkedMapOf<String, DeviceContact>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val cursor: Cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY + " COLLATE LOCALIZED ASC"
        ) ?: return emptyList()
        cursor.use {
            val nameColumn = it.getColumnIndexOrThrow(projection[0])
            val numberColumn = it.getColumnIndexOrThrow(projection[1])
            while (it.moveToNext()) {
                val name = it.getString(nameColumn)?.trim().orEmpty()
                val digits = normalizePhone(it.getString(numberColumn).orEmpty())
                if (name.isNotBlank() && digits.length >= 10) result.putIfAbsent(digits, DeviceContact(name, digits))
            }
        }
        return result.values.toList()
    }

    private fun showNewConversation() {
        onHomeScreen = false
        base("Nova conversa")
        val contacts = readContacts()
        if (contacts.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "Nenhum contato com telefone foi encontrado. Confirme se os contatos Google estão sincronizados nas configurações do Android."
                contentDescription = text
            })
        } else {
            root.addView(TextView(this).apply {
                text = "${contacts.size} contatos encontrados. Escolha um contato."
                contentDescription = text
                accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            })
            contacts.forEach { contact ->
                root.addView(button(contact.name) {
                    val jid = "${contact.number}@s.whatsapp.net"
                    recentChats[jid] = contact.name
                    showChat(contact.name, jid)
                })
            }
        }
        root.addView(button("Digitar outro número") { showChat("Novo número", null) })
        root.addView(button("Voltar para conversas") { showConversations() })
    }

    private fun showChat(contactName: String, initialJid: String?) {
        onHomeScreen = false
        activeChatJid = initialJid
        base("Conversa com $contactName")
        val recipient = EditText(this).apply {
            hint = "Número com país e DDD"
            contentDescription = "Número do destinatário com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
            visibility = if (initialJid == null) View.VISIBLE else View.GONE
        }
        val message = EditText(this).apply {
            hint = "Digite uma mensagem"
            contentDescription = "Mensagem"
            minLines = 2
        }
        root.addView(recipient)
        activityStatus = TextView(this).apply {
            text = ""; contentDescription = ""
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(activityStatus)
        val sendButton = button("Enviar") {
            val jid = activeChatJid ?: recipientJid(recipient) ?: return@button
            activeChatJid = jid
            recentChats[jid] = contactName
            val body = message.text.toString().trim()
            if (body.isBlank()) { announce("Digite uma mensagem"); return@button }
            runProtocol("Enviando mensagem", "Mensagem enviada", {
                appendMessage("Você: $body")
                message.text.clear()
            }) { protocol.sendText(jid, body) }
        }

        val recordButton = button("Microfone") {}
        var recording = false
        var pressing = false

        fun startRecording() {
            if (recording) return
            requestMicrophone {
                if (!pressing && !isTouchExplorationEnabled()) return@requestMicrophone
                runCatching { voiceRecorder.start() }.onSuccess {
                    recording = true
                    recordedVoice = null
                    recordButton.text = "Solte para enviar"
                    recordButton.contentDescription = "Gravando áudio. Solte para enviar"
                    vibrateCue()
                    announce("Gravação iniciada")
                }.onFailure { announce("Não foi possível iniciar a gravação: ${it.message}") }
            }
        }

        fun finishAndSend() {
            if (!recording) return
            runCatching { voiceRecorder.stop() }.onSuccess { voice ->
                recording = false
                recordedVoice = voice
                recordButton.text = "Microfone"
                recordButton.contentDescription = "Segure para gravar uma mensagem de voz"
                vibrateCue()
                val jid = activeChatJid ?: recipientJid(recipient) ?: return@onSuccess
                activeChatJid = jid
                runProtocol("Enviando áudio", "Áudio enviado", {
                    voice.file.delete()
                    recordedVoice = null
                }) { protocol.sendVoice(jid, voice.file.absolutePath, voice.durationSeconds) }
            }.onFailure {
                recording = false
                recordButton.text = "Microfone"
                announce("Falha ao finalizar a gravação: ${it.message}")
            }
        }

        recordButton.contentDescription = "Segure para gravar uma mensagem de voz"
        recordButton.setOnTouchListener { _, event ->
            if (isTouchExplorationEnabled()) return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { pressing = true; startRecording(); true }
                MotionEvent.ACTION_UP -> { pressing = false; finishAndSend(); true }
                MotionEvent.ACTION_CANCEL -> {
                    pressing = false
                    if (recording) { voiceRecorder.cancel(); recording = false; announce("Gravação cancelada") }
                    recordButton.text = "Microfone"
                    true
                }
                else -> true
            }
        }
        recordButton.setOnClickListener {
            // TalkBack transforma o gesto de toque em clique. Nesse modo, um clique
            // inicia e o próximo envia, mantendo o controle acessível.
            if (!isTouchExplorationEnabled()) return@setOnClickListener
            if (!recording) {
                pressing = true
                startRecording()
            } else {
                pressing = false
                finishAndSend()
            }
        }
        root.addView(TextView(this).apply {
            text = "Mensagens desta sessão"; isAccessibilityHeading = true
        })
        messageLog = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(messageLog)
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            addView(message, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sendButton)
            addView(recordButton)
        })
        root.addView(button("Voltar para conversas") { if (recording) voiceRecorder.cancel(); showConversations() })
    }

    private fun recipientJid(field: EditText): String? {
        val digits = normalizePhone(field.text.toString())
        if (digits.length < 10) { announce("Digite o número com país e DDD"); return null }
        return "$digits@s.whatsapp.net"
    }

    private fun normalizePhone(value: String): String {
        val digits = value.filter(Char::isDigit)
        return if (digits.length == 10 || digits.length == 11) "55$digits" else digits
    }

    private fun contactNameForJid(jid: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val digits = jid.substringBefore('@').filter(Char::isDigit)
        return readContacts().firstOrNull { contact ->
            contact.number.endsWith(digits) || digits.endsWith(contact.number)
        }?.name
    }

    private fun appendMessage(accessibleText: String) {
        messageLog?.addView(TextView(this).apply { text = accessibleText; contentDescription = accessibleText })
        messageLog?.announceForAccessibility(accessibleText)
    }

    private fun runProtocol(start: String, success: String, onSuccess: () -> Unit = {}, action: () -> Unit) {
        announce(start)
        Thread {
            runCatching(action).onSuccess { runOnUiThread { onSuccess(); announce(success) } }
                .onFailure { runOnUiThread { announce("Falha: ${it.message ?: "erro desconhecido"}") } }
        }.start()
    }

    private fun requestMicrophone(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingRecordAction = action; microphonePermission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun isTouchExplorationEnabled(): Boolean =
        (getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager).isTouchExplorationEnabled

    private fun vibrateCue() {
        if (!prefs.vibration) return
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        }
        if (vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun showPairing() {
        onHomeScreen = false
        base("Parear aparelho")
        val status = TextView(this).apply {
            text = "Escolha pareamento por QR Code ou telefone"; contentDescription = text
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        }
        root.addView(status)
        root.addView(button("Gerar QR Code") {
            status.text = "Solicitando novo QR Code"
            protocol.requestQrPairing { state -> runOnUiThread { renderProtocolState(state, status) } }
        })
        val phone = EditText(this).apply {
            hint = "Número com país e DDD, por exemplo 5511999999999"
            contentDescription = "Número de telefone com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(phone)
        root.addView(button("Gerar código por telefone") {
            val normalized = normalizePhone(phone.text.toString())
            if (normalized.length < 10) announce("Digite um número válido com código do país e DDD")
            else protocol.requestPhonePairing(normalized) { state ->
                runOnUiThread { renderProtocolState(state, status) }
            }
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun renderProtocolState(state: ProtocolGateway.State, status: TextView) {
        val message = when (state) {
            ProtocolGateway.State.Disconnected -> stateLabel(state)
            ProtocolGateway.State.Connecting -> stateLabel(state)
            is ProtocolGateway.State.QrReady -> {
                showQrCode(state.payload)
                "Novo QR Code disponível"
            }
            is ProtocolGateway.State.PairCodeReady -> {
                val spokenCode = state.code.filter(Char::isLetterOrDigit).replace("", " ").trim()
                "Código de pareamento. $spokenCode. Toque duas vezes para selecionar e copiar."
            }
            ProtocolGateway.State.Connected -> stateLabel(state)
            is ProtocolGateway.State.Failed -> state.accessibleMessage
        }
        status.text = message
        status.contentDescription = message
        status.isFocusable = true
        status.isClickable = state is ProtocolGateway.State.PairCodeReady
        status.setOnClickListener(if (state is ProtocolGateway.State.PairCodeReady) View.OnClickListener {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Código de pareamento", state.code))
            announce("Código de pareamento copiado")
        } else null)
        status.postDelayed({
            status.requestFocus()
            status.sendAccessibilityEvent(AccessibilityEvent.TYPE_ANNOUNCEMENT)
            announce(message)
        }, 350)
    }

    private fun stateLabel(state: ProtocolGateway.State): String = when (state) {
        ProtocolGateway.State.Disconnected -> "desconectado"
        ProtocolGateway.State.Connecting -> "conectando"
        is ProtocolGateway.State.QrReady -> "aguardando leitura do QR Code"
        is ProtocolGateway.State.PairCodeReady -> "aguardando confirmação do código"
        ProtocolGateway.State.Connected -> "conta conectada"
        is ProtocolGateway.State.Failed -> "erro: ${state.accessibleMessage}"
    }

    private fun showQrCode(payload: String) {
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 720, 720)
        val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
        for (x in 0 until matrix.width) for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
        qrImage?.let(root::removeView)
        qrImage = ImageView(this).apply {
            setImageBitmap(bitmap)
            contentDescription = "QR Code de vinculação do Droid Zap. Use o WhatsApp principal para escanear."
            adjustViewBounds = true
        }
        root.addView(qrImage, 2)
    }

    private fun showSettings() {
        onHomeScreen = false
        base("Configurações")
        fun option(label: String, checked: Boolean, update: (Boolean) -> Unit) = CheckBox(this).apply {
            text = label; isChecked = checked; contentDescription = label
            setOnCheckedChangeListener { _, value -> update(value) }
        }
        root.addView(option("Vibrar nos avisos", prefs.vibration) { prefs.vibration = it })
        root.addView(button("Notificações") { showNotificationSettings() })
        root.addView(button("Voltar") { showHome() })
    }

    private fun showNotificationSettings() {
        onHomeScreen = false
        base("Notificações")
        fun toneSelector(title: String, target: RingtoneTarget, uriValue: String) {
            root.addView(TextView(this).apply {
                text = title
                contentDescription = title
                isAccessibilityHeading = true
            })
            val current = ringtoneTitle(uriValue)
            root.addView(TextView(this).apply { text = "Selecionado: $current"; contentDescription = text })
            root.addView(button("Escolher toque para $title") {
                ringtoneTarget = target
                val currentUri = uriValue.takeIf(String::isNotBlank)?.let(Uri::parse)
                ringtonePicker.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, currentUri)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, title)
                })
            })
            root.addView(button("Ouvir toque de $title") { playSystemRingtone(uriValue) })
        }

        toneSelector("mensagens privadas", RingtoneTarget.PRIVATE, prefs.privateRingtoneUri)
        toneSelector("mensagens de grupos", RingtoneTarget.GROUP, prefs.groupRingtoneUri)
        root.addView(TextView(this).apply {
            text = "O Droid Zap usa os sons de notificação que já estão disponíveis neste celular."
            contentDescription = text
        })
        root.addView(button("Voltar para configurações") { showSettings() })
    }

    private fun ringtoneTitle(value: String): String {
        if (value.isBlank()) return "Silencioso"
        return runCatching { RingtoneManager.getRingtone(this, Uri.parse(value))?.getTitle(this) }
            .getOrNull().orEmpty().ifBlank { "Som padrão" }
    }

    private fun playSystemRingtone(value: String) {
        if (value.isBlank()) return
        runCatching { RingtoneManager.getRingtone(this, Uri.parse(value))?.play() }
    }

    private fun announce(message: String) {
        window.decorView.announceForAccessibility(message)
    }

    override fun onDestroy() { voiceRecorder.cancel(); protocol.disconnect(); super.onDestroy() }
}
