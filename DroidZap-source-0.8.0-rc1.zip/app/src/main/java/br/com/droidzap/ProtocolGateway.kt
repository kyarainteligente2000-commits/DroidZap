package br.com.droidzap

/** Boundary between the native Android UI and the embedded protocol runtime. */
interface ProtocolGateway {
    data class IncomingMessage(
        val chatJid: String,
        val chatName: String,
        val senderJid: String,
        val senderName: String,
        val isGroup: Boolean,
        val text: String,
        val timestamp: Long,
    )

    sealed interface State {
        data object Disconnected : State
        data object Connecting : State
        data class QrReady(val payload: String, val expiresAtMillis: Long) : State
        data class PairCodeReady(val code: String) : State
        data object Connected : State
        data class Failed(val accessibleMessage: String) : State
    }

    fun currentState(): State
    fun observeState(observer: (State) -> Unit)
    fun requestQrPairing(onState: (State) -> Unit)
    fun requestPhonePairing(phoneE164: String, onState: (State) -> Unit)
    fun sendText(chatJid: String, text: String)
    fun sendVoice(chatJid: String, filePath: String, durationSeconds: Long)
    fun observeMessages(observer: (IncomingMessage) -> Unit)
    fun observeChatActivity(observer: (chatJid: String, senderJid: String, activity: String, active: Boolean) -> Unit)
    fun disconnect()
}
