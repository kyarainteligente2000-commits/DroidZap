plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.droidzap"
    compileSdk = 36

    defaultConfig {
        applicationId = "br.com.droidzap"
        minSdk = 30
        targetSdk = 36
        versionCode = 17
        versionName = "0.8.0-rc1"
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("DROIDZAP_KEYSTORE_PATH")
            if (!keystorePath.isNullOrBlank()) {
                storeFile = file(keystorePath)
                storePassword = System.getenv("DROIDZAP_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("DROIDZAP_KEY_ALIAS")
                keyPassword = System.getenv("DROIDZAP_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(files("libs/droidzapbridge.aar"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.play:app-update-ktx:2.1.0")
    implementation("com.google.zxing:core:3.5.3")
}
