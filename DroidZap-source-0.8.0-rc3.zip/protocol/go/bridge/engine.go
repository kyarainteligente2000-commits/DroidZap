// Package bridge exposes a gomobile-compatible API for the Droid Zap UI.
package bridge

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"go.mau.fi/whatsmeow"
	waE2E "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	"google.golang.org/protobuf/proto"
)

type Listener interface {
	OnState(state string, detail string)
	OnQRCode(payload string, validForSeconds int64)
	OnPairCode(code string)
	OnMessage(messageID string, chatJID string, chatName string, senderJID string, senderName string, isGroup bool, fromMe bool, kind string, text string, mediaPath string, durationSeconds int64, timestamp int64, historical bool)
	OnChatActivity(chatJID string, senderJID string, activity string, active bool)
}

type Engine struct {
	mu        sync.Mutex
	client    *whatsmeow.Client
	container *sqlstore.Container
	listener  Listener
	cancel    context.CancelFunc
	running   bool
	mediaDir  string
}

func NewEngine(listener Listener) *Engine { return &Engine{listener: listener} }

func (e *Engine) emit(state, detail string) {
	if e.listener != nil {
		e.listener.OnState(state, detail)
	}
}

// Start opens (or creates) the encrypted-session database in Android app-private storage.
// Android is responsible for protecting the containing directory and backup policy.
func (e *Engine) Start(databasePath string) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.client != nil {
		return nil
	}
	db, err := sql.Open("sqlite3", "file:"+databasePath+"?_foreign_keys=on")
	if err != nil {
		return fmt.Errorf("open session database: %w", err)
	}
	container := sqlstore.NewWithDB(db, "sqlite3", nil)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	if err = container.Upgrade(ctx); err != nil {
		_ = db.Close()
		return fmt.Errorf("upgrade session database: %w", err)
	}
	device, err := container.GetFirstDevice(ctx)
	if err != nil {
		_ = container.Close()
		return fmt.Errorf("load session: %w", err)
	}
	client := whatsmeow.NewClient(device, nil)
	client.AddEventHandler(e.handleEvent)
	e.container, e.client = container, client
	e.mediaDir = filepath.Join(filepath.Dir(databasePath), "voice_messages")
	if err = os.MkdirAll(e.mediaDir, 0700); err != nil {
		return fmt.Errorf("create media directory: %w", err)
	}
	if device.ID != nil {
		go func() {
			e.emit("connecting", "Restaurando sessão")
			if connectErr := client.Connect(); connectErr != nil {
				e.emit("error", connectErr.Error())
			}
		}()
	}
	return nil
}

func (e *Engine) RequestQR() error { return e.startPairing("") }

func (e *Engine) RequestPhone(phone string) error {
	phone = strings.TrimPrefix(strings.TrimSpace(phone), "+")
	if len(phone) < 10 {
		return errors.New("número deve incluir país e DDD")
	}
	return e.startPairing(phone)
}

func (e *Engine) startPairing(phone string) error {
	e.mu.Lock()
	if e.client == nil {
		e.mu.Unlock()
		return errors.New("módulo não iniciado")
	}
	if e.client.Store.ID != nil {
		e.mu.Unlock()
		return errors.New("já existe uma conta pareada")
	}
	if e.running {
		e.mu.Unlock()
		return errors.New("pareamento já está em andamento")
	}
	ctx, cancel := context.WithCancel(context.Background())
	e.cancel, e.running = cancel, true
	client := e.client
	e.mu.Unlock()
	go e.pairLoop(ctx, client, phone)
	return nil
}

func (e *Engine) pairLoop(ctx context.Context, client *whatsmeow.Client, phone string) {
	defer func() { e.mu.Lock(); e.running = false; e.mu.Unlock() }()
	for ctx.Err() == nil && client.Store.ID == nil {
		qrChannel, err := client.GetQRChannel(ctx)
		if err != nil {
			e.emit("error", err.Error())
			return
		}
		e.emit("connecting", "Solicitando pareamento")
		if err = client.Connect(); err != nil {
			e.emit("error", err.Error())
			return
		}
		phoneRequested := false
		paired := false
		for item := range qrChannel {
			switch item.Event {
			case "code":
				if phone != "" && !phoneRequested {
					phoneRequested = true
					// Use one coherent companion identity. Mixing an Android client type with
					// a Chrome display name can make the primary device reject synchronization.
					code, pairErr := client.PairPhone(ctx, phone, true, whatsmeow.PairClientChrome, "Chrome (Android)")
					if pairErr != nil {
						e.emit("error", pairErr.Error())
						return
					}
					if e.listener != nil {
						e.listener.OnPairCode(code)
					}
					e.emit("pair_code", "Código por telefone disponível")
				} else if phone == "" && e.listener != nil {
					e.listener.OnQRCode(item.Code, int64(item.Timeout/time.Second))
					e.emit("qr", "Novo QR Code disponível")
				}
			case "success":
				paired = true
				e.emit("connected", "Conta vinculada")
			case "timeout":
				e.emit("refreshing_qr", "QR expirado; solicitando outro")
			default:
				if item.Error != nil {
					e.emit("error", item.Error.Error())
				}
			}
		}
		if paired || client.Store.ID != nil || ctx.Err() != nil {
			return
		}
		client.Disconnect()
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Second):
		}
	}
}

func (e *Engine) SendText(chatJID, text string) error {
	e.mu.Lock()
	client := e.client
	e.mu.Unlock()
	if client == nil || !client.IsConnected() {
		return errors.New("conta desconectada")
	}
	jid, err := types.ParseJID(chatJID)
	if err != nil {
		return fmt.Errorf("destino inválido: %w", err)
	}
	text = strings.TrimSpace(text)
	if text == "" {
		return errors.New("mensagem vazia")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	_, err = client.SendMessage(ctx, jid, &waE2E.Message{Conversation: proto.String(text)})
	return err
}

// SendVoice uploads an Android-recorded Ogg/Opus file and sends it as a push-to-talk message.
func (e *Engine) SendVoice(chatJID, filePath string, durationSeconds int64) error {
	e.mu.Lock()
	client := e.client
	e.mu.Unlock()
	if client == nil || !client.IsConnected() {
		return errors.New("conta desconectada")
	}
	jid, err := types.ParseJID(chatJID)
	if err != nil {
		return fmt.Errorf("destino inválido: %w", err)
	}
	data, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("ler gravação: %w", err)
	}
	if len(data) == 0 {
		return errors.New("gravação vazia")
	}
	if durationSeconds < 1 {
		durationSeconds = 1
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	upload, err := client.Upload(ctx, data, whatsmeow.MediaAudio)
	if err != nil {
		return fmt.Errorf("enviar áudio: %w", err)
	}
	seconds := uint32(durationSeconds)
	voice := &waE2E.AudioMessage{
		URL: &upload.URL, DirectPath: &upload.DirectPath,
		MediaKey: upload.MediaKey, FileEncSHA256: upload.FileEncSHA256,
		FileSHA256: upload.FileSHA256, FileLength: &upload.FileLength,
		Mimetype: proto.String("audio/ogg; codecs=opus"), Seconds: &seconds,
		PTT: proto.Bool(true),
	}
	_, err = client.SendMessage(ctx, jid, &waE2E.Message{AudioMessage: voice})
	return err
}

func (e *Engine) handleEvent(raw any) {
	switch evt := raw.(type) {
	case *events.Connected:
		e.emit("connected", "Conta conectada")
		go func() {
			if err := e.client.SendPresence(context.Background(), types.PresenceAvailable); err != nil {
				e.emit("warning", "Avisos de digitação podem não estar disponíveis")
			}
		}()
	case *events.Disconnected:
		e.emit("disconnected", "Conta desconectada")
	case *events.Message:
		if e.listener == nil {
			return
		}
		go e.emitMessage(evt, "", false)
	case *events.HistorySync:
		if evt.Data == nil {
			return
		}
		go e.emitHistory(evt)
	case *events.ChatPresence:
		if e.listener == nil {
			return
		}
		activity := "typing"
		if evt.Media == types.ChatPresenceMediaAudio {
			activity = "recording"
		}
		e.listener.OnChatActivity(evt.Chat.String(), evt.Sender.String(), activity, evt.State == types.ChatPresenceComposing)
	}
}

func (e *Engine) emitHistory(evt *events.HistorySync) {
	for _, conversation := range evt.Data.GetConversations() {
		chat, err := types.ParseJID(conversation.GetID())
		if err != nil {
			continue
		}
		chatName := strings.TrimSpace(conversation.GetName())
		if chatName == "" {
			chatName = strings.TrimSpace(conversation.GetDisplayName())
		}
		for _, item := range conversation.GetMessages() {
			parsed, parseErr := e.client.ParseWebMessage(chat, item.GetMessage())
			if parseErr == nil && parsed != nil {
				e.emitMessage(parsed, chatName, true)
			}
		}
	}
}

func (e *Engine) emitMessage(evt *events.Message, knownChatName string, historical bool) {
	e.mu.Lock()
	client := e.client
	listener := e.listener
	mediaDir := e.mediaDir
	e.mu.Unlock()
	if client == nil || listener == nil {
		return
	}
	chat := evt.Info.Chat
	sender := evt.Info.Sender

	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	isGroup := strings.HasSuffix(chat.String(), "@g.us")
	senderName := contactName(ctx, client, sender)
	chatName := strings.TrimSpace(knownChatName)
	if chatName == "" {
		chatName = senderName
	}
	if isGroup {
		if chatName == "" {
			chatName = "Grupo"
		}
		if info, err := client.GetGroupInfo(ctx, chat); err == nil && strings.TrimSpace(info.Name) != "" && knownChatName == "" {
			chatName = strings.TrimSpace(info.Name)
		}
	} else if knownChatName == "" {
		chatName = contactName(ctx, client, chat)
	}

	kind := "text"
	text := evt.Message.GetConversation()
	if text == "" {
		text = evt.Message.GetExtendedTextMessage().GetText()
	}
	mediaPath := ""
	duration := int64(0)
	if audio := evt.Message.GetAudioMessage(); audio != nil {
		kind = "audio"
		duration = int64(audio.GetSeconds())
		mediaPath = filepath.Join(mediaDir, string(evt.Info.ID)+".ogg")
		if _, err := os.Stat(mediaPath); errors.Is(err, os.ErrNotExist) {
			file, createErr := os.Create(mediaPath)
			if createErr == nil {
				downloadErr := client.DownloadToFile(ctx, audio, file)
				_ = file.Close()
				if downloadErr != nil {
					_ = os.Remove(mediaPath)
					mediaPath = ""
				}
			}
		}
	} else if evt.Message.GetImageMessage() != nil {
		kind = "image"
		text = evt.Message.GetImageMessage().GetCaption()
	} else if evt.Message.GetDocumentMessage() != nil {
		kind = "document"
		text = evt.Message.GetDocumentMessage().GetFileName()
	} else if text == "" {
		kind = "unsupported"
	}
	listener.OnMessage(string(evt.Info.ID), chat.String(), chatName, sender.String(), senderName, isGroup, evt.Info.IsFromMe, kind, text, mediaPath, duration, evt.Info.Timestamp.Unix(), historical)
}

func contactName(ctx context.Context, client *whatsmeow.Client, jid types.JID) string {
	if info, err := client.Store.Contacts.GetContact(ctx, jid); err == nil {
		for _, candidate := range []string{info.FullName, info.FirstName, info.BusinessName, info.PushName, info.RedactedPhone} {
			if name := strings.TrimSpace(candidate); name != "" {
				return name
			}
		}
	}
	if user := strings.TrimSpace(jid.User); user != "" {
		return user
	}
	return "Contato"
}

func (e *Engine) Stop() {
	e.mu.Lock()
	if e.cancel != nil {
		e.cancel()
	}
	if e.client != nil {
		e.client.Disconnect()
	}
	if e.container != nil {
		_ = e.container.Close()
	}
	e.client, e.container, e.cancel, e.running = nil, nil, nil, false
	e.mu.Unlock()
}
