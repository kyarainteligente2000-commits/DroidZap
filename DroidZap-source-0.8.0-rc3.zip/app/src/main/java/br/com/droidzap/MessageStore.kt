package br.com.droidzap

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MessageStore(context: Context) : SQLiteOpenHelper(context, "droidzap-messages.db", null, 1) {
    data class Conversation(
        val jid: String,
        val title: String,
        val isGroup: Boolean,
        val lastPreview: String,
        val lastTimestamp: Long,
        val unreadCount: Int,
    )

    data class Message(
        val id: String,
        val chatJid: String,
        val senderName: String,
        val fromMe: Boolean,
        val kind: String,
        val body: String,
        val mediaPath: String,
        val durationSeconds: Long,
        val timestamp: Long,
    )

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE conversations (
                jid TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                is_group INTEGER NOT NULL,
                last_preview TEXT NOT NULL,
                last_timestamp INTEGER NOT NULL,
                unread_count INTEGER NOT NULL DEFAULT 0
            )"""
        )
        db.execSQL(
            """CREATE TABLE messages (
                id TEXT PRIMARY KEY,
                chat_jid TEXT NOT NULL,
                sender_name TEXT NOT NULL,
                from_me INTEGER NOT NULL,
                kind TEXT NOT NULL,
                body TEXT NOT NULL,
                media_path TEXT NOT NULL,
                duration_seconds INTEGER NOT NULL,
                timestamp INTEGER NOT NULL
            )"""
        )
        db.execSQL("CREATE INDEX messages_chat_time ON messages(chat_jid, timestamp)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun saveConversation(jid: String, title: String, isGroup: Boolean, preview: String, timestamp: Long, unread: Boolean) {
        val existingUnread = readableDatabase.rawQuery(
            "SELECT unread_count FROM conversations WHERE jid = ?", arrayOf(jid)
        ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        writableDatabase.insertWithOnConflict("conversations", null, ContentValues().apply {
            put("jid", jid)
            put("title", title.ifBlank { "Contato" })
            put("is_group", if (isGroup) 1 else 0)
            put("last_preview", preview)
            put("last_timestamp", timestamp)
            put("unread_count", existingUnread + if (unread) 1 else 0)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    @Synchronized
    fun saveMessage(message: Message) {
        writableDatabase.insertWithOnConflict("messages", null, ContentValues().apply {
            put("id", message.id)
            put("chat_jid", message.chatJid)
            put("sender_name", message.senderName)
            put("from_me", if (message.fromMe) 1 else 0)
            put("kind", message.kind)
            put("body", message.body)
            put("media_path", message.mediaPath)
            put("duration_seconds", message.durationSeconds)
            put("timestamp", message.timestamp)
        }, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun conversations(query: String = ""): List<Conversation> {
        val selection = if (query.isBlank()) null else "title LIKE ?"
        val args = if (query.isBlank()) null else arrayOf("%$query%")
        return readableDatabase.query(
            "conversations", null, selection, args, null, null, "last_timestamp DESC"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) add(Conversation(
                    jid = cursor.getString(cursor.getColumnIndexOrThrow("jid")),
                    title = cursor.getString(cursor.getColumnIndexOrThrow("title")),
                    isGroup = cursor.getInt(cursor.getColumnIndexOrThrow("is_group")) == 1,
                    lastPreview = cursor.getString(cursor.getColumnIndexOrThrow("last_preview")),
                    lastTimestamp = cursor.getLong(cursor.getColumnIndexOrThrow("last_timestamp")),
                    unreadCount = cursor.getInt(cursor.getColumnIndexOrThrow("unread_count")),
                ))
            }
        }
    }

    fun messages(chatJid: String): List<Message> = readableDatabase.query(
        "messages", null, "chat_jid = ?", arrayOf(chatJid), null, null, "timestamp ASC"
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(Message(
                id = cursor.getString(cursor.getColumnIndexOrThrow("id")),
                chatJid = cursor.getString(cursor.getColumnIndexOrThrow("chat_jid")),
                senderName = cursor.getString(cursor.getColumnIndexOrThrow("sender_name")),
                fromMe = cursor.getInt(cursor.getColumnIndexOrThrow("from_me")) == 1,
                kind = cursor.getString(cursor.getColumnIndexOrThrow("kind")),
                body = cursor.getString(cursor.getColumnIndexOrThrow("body")),
                mediaPath = cursor.getString(cursor.getColumnIndexOrThrow("media_path")),
                durationSeconds = cursor.getLong(cursor.getColumnIndexOrThrow("duration_seconds")),
                timestamp = cursor.getLong(cursor.getColumnIndexOrThrow("timestamp")),
            ))
        }
    }

    fun markRead(chatJid: String) {
        writableDatabase.update("conversations", ContentValues().apply { put("unread_count", 0) }, "jid = ?", arrayOf(chatJid))
    }
}
