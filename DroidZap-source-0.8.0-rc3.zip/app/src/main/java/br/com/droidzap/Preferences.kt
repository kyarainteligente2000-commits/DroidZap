package br.com.droidzap

import android.content.Context
import android.provider.Settings

class Preferences(context: Context) {
    private val store = context.getSharedPreferences("droid_zap", Context.MODE_PRIVATE)
    var vibration: Boolean
        get() = store.getBoolean("vibration", true)
        set(value) = store.edit().putBoolean("vibration", value).apply()
    var privateRingtoneUri: String
        get() = store.getString("private_ringtone_uri", Settings.System.DEFAULT_NOTIFICATION_URI.toString()).orEmpty()
        set(value) = store.edit().putString("private_ringtone_uri", value).apply()

    var groupRingtoneUri: String
        get() = store.getString("group_ringtone_uri", Settings.System.DEFAULT_NOTIFICATION_URI.toString()).orEmpty()
        set(value) = store.edit().putString("group_ringtone_uri", value).apply()
}
