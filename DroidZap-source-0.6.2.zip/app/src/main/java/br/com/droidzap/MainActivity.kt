package br.com.droidzap

import android.annotation.SuppressLint
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.addCallback
import androidx.core.content.ContextCompat
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var prefs: Preferences
    private val tones = ToneEngine()
    private var tts: TextToSpeech? = null
    private var lastPresence = ""
    private var onHomeScreen = true
    private val updateRequestCode = 7401
    private var pendingWebPermission: PermissionRequest? = null
    private var pendingWebResources = emptyArray<String>()
    private val mediaPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val request = pendingWebPermission
        val resources = pendingWebResources
        pendingWebPermission = null
        pendingWebResources = emptyArray()
        val audioOk = PermissionRequest.RESOURCE_AUDIO_CAPTURE !in resources ||
            results[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val videoOk = PermissionRequest.RESOURCE_VIDEO_CAPTURE !in resources ||
            results[Manifest.permission.CAMERA] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (audioOk && videoOk) {
            request?.grant(resources)
            announceStatus(if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in resources)
                "Microfone e câmera permitidos. A chamada está pronta."
            else "Microfone permitido. A gravação está pronta.")
        } else {
            request?.deny()
            announceStatus("Permissão de microfone ou câmera negada. A gravação ou chamada não poderá começar.")
        }
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        prefs = Preferences(this)
        tts = TextToSpeech(this, this)
        onBackPressedDispatcher.addCallback(this) {
            if (onHomeScreen) finish() else showHome()
        }
        showHome()
        checkForUpdate(interactive = false)
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 24f; contentDescription = title
                isAccessibilityHeading = true
            })
        }
        setContentView(root)
        return root
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; contentDescription = label; setOnClickListener { action() }
    }

    private fun showHome() {
        onHomeScreen = true
        base("Droid Zap")
        root.addView(TextView(this).apply {
            text = "Cliente acessível em modo de dispositivo vinculado"
            contentDescription = text
        })
        root.addView(button("Abrir conversas") { showWhatsApp() })
        root.addView(button("Configurações de acessibilidade e sons") { showSettings() })
        root.addView(button("Procurar atualização") { checkForUpdate(interactive = true) })
    }

    /**
     * Uses Google Play's signed update channel. Android/Play validates that a
     * downloaded version belongs to this app before allowing installation.
     */
    private fun checkForUpdate(interactive: Boolean) {
        val manager = AppUpdateManagerFactory.create(this)
        manager.appUpdateInfo
            .addOnSuccessListener { info ->
                if (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                    info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                    announceStatus("Atualização encontrada. Abrindo a instalação.")
                    manager.startUpdateFlowForResult(
                        info, AppUpdateType.IMMEDIATE, this, updateRequestCode
                    )
                } else if (interactive) {
                    announceStatus("O Droid Zap já está atualizado.")
                }
            }
            .addOnFailureListener {
                if (interactive) announceStatus(
                    "Não foi possível procurar atualização. Verifique a internet e se o aplicativo foi instalado pela Play Store."
                )
            }
    }

    private fun announceStatus(message: String) {
        window.decorView.announceForAccessibility(message)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "update_status")
    }

    private fun showSettings() {
        onHomeScreen = false
        base("Configurações")
        fun option(label: String, checked: Boolean, update: (Boolean) -> Unit) =
            CheckBox(this).apply {
                text = label; isChecked = checked; contentDescription = label
                setOnCheckedChangeListener { _, value -> update(value) }
            }
        root.addView(option("Falar quando alguém estiver digitando ou gravando", prefs.spokenAlerts) { prefs.spokenAlerts = it })
        root.addView(option("Vibrar nos avisos de presença", prefs.vibration) { prefs.vibration = it })
        root.addView(option("Som ao digitar no campo de mensagem", prefs.keyboardSound) { prefs.keyboardSound = it })
        root.addView(TextView(this).apply { text = "Categoria de som"; labelFor = View.NO_ID })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                ToneEngine.Style.entries.map { it.label })
            setSelection(ToneEngine.Style.entries.indexOf(prefs.style))
            contentDescription = "Categoria de som"
        }
        root.addView(spinner)
        root.addView(button("Ouvir amostra") {
            prefs.style = ToneEngine.Style.entries[spinner.selectedItemPosition]
            tones.play(prefs.style)
            spinner.announceForAccessibility("Amostra ${prefs.style.label}")
        })
        root.addView(button("Voltar") { showHome() })
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun showWhatsApp() {
        onHomeScreen = false
        val web = WebView(this)
        setContentView(web)
        web.contentDescription = "Conversas do WhatsApp. Página em modo de dispositivo vinculado."
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = userAgentString.replace("; wv", "")
                .replace(Regex("Mobile|Android"), "") + " DroidZap/0.1"
        }
        web.addJavascriptInterface(PageBridge(), "DroidZap")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val trusted = Uri.parse(request.origin.toString()).host == "web.whatsapp.com"
                    val supported = request.resources.all {
                        it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                    }
                    if (!trusted || !supported) {
                        request.deny()
                        return@runOnUiThread
                    }
                    val needed = buildList {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in request.resources &&
                            ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                            add(Manifest.permission.RECORD_AUDIO)
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in request.resources &&
                            ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                            add(Manifest.permission.CAMERA)
                    }
                    if (needed.isEmpty()) {
                        request.grant(request.resources)
                    } else {
                        pendingWebPermission?.deny()
                        pendingWebPermission = request
                        pendingWebResources = request.resources
                        mediaPermissions.launch(needed.toTypedArray())
                    }
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingWebPermission == request) {
                    pendingWebPermission = null
                    pendingWebResources = emptyArray()
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == "web.whatsapp.com") return false
                if (uri.scheme == "https" || uri.scheme == "http") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
                return true
            }
            override fun onPageFinished(view: WebView, url: String) {
                if (Uri.parse(url).host == "web.whatsapp.com") {
                    view.evaluateJavascript(observerScript(), null)
                }
            }
        }
        web.loadUrl("https://web.whatsapp.com/")
    }

    private fun observerScript() = """
        (() => {
          if (window.__droidZapInstalled) return;
          window.__droidZapInstalled = true;
          // Ask WebRTC for a voice-optimized mono stream. Browsers may ignore
          // unsupported constraints, so this remains compatible across phones.
          if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            const originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
            navigator.mediaDevices.getUserMedia = constraints => {
              if (constraints && constraints.audio) {
                constraints = Object.assign({}, constraints, { audio: {
                  channelCount: { ideal: 1 }, sampleRate: { ideal: 48000 },
                  sampleSize: { ideal: 16 }, echoCancellation: { ideal: true },
                  noiseSuppression: { ideal: true }, autoGainControl: { ideal: true }
                }});
              }
              return originalGetUserMedia(constraints);
            };
          }
          let last = '';
          const scan = () => {
            const text = document.body ? document.body.innerText : '';
            const lines = text.split('\\n').map(x => x.trim()).filter(Boolean);
            const status = lines.find(x => /^(digitando|typing|escrevendo|gravando( áudio)?|recording( audio)?)\\.{0,3}$/i.test(x)) || '';
            if (status !== last) { last = status; DroidZap.presence(status); }
          };
          new MutationObserver(scan).observe(document.documentElement, {subtree:true, childList:true, characterData:true});
          document.addEventListener('input', e => {
            if (e.target && (e.target.isContentEditable || e.target.tagName === 'TEXTAREA')) DroidZap.keyPressed();
          }, true);
          scan();
        })();
    """.trimIndent()

    inner class PageBridge {
        @JavascriptInterface fun presence(value: String) = runOnUiThread {
            if (value.length > 40) return@runOnUiThread
            if (value.isBlank() || value == lastPresence) return@runOnUiThread
            lastPresence = value
            val recording = value.contains("grav", true) || value.contains("record", true)
            announce(if (recording) "Contato gravando áudio" else "Contato digitando")
        }
        @JavascriptInterface fun keyPressed() {
            if (prefs.keyboardSound) tones.keyboardClick(prefs.style)
        }
    }

    private fun announce(message: String) {
        window.decorView.announceForAccessibility(message)
        if (prefs.spokenAlerts) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "presence")
        if (prefs.vibration) (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            .vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        tones.play(prefs.style)
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
