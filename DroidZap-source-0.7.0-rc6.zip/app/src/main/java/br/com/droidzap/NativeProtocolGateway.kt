package br.com.droidzap

import android.content.Context
import bridge.Engine
import bridge.Listener
import bridge.Bridge

class NativeProtocolGateway(context: Context) : ProtocolGateway, Listener {
    private var observer: ((ProtocolGateway.State) -> Unit)? = null
    private var stateObserver: ((ProtocolGateway.State) -> Unit)? = null
    private var messageObserver: ((String, String, String, Long) -> Unit)? = null
    private var activityObserver: ((String, String, String, Boolean) -> Unit)? = null
    private var state: ProtocolGateway.State = ProtocolGateway.State.Disconnected
    private val engine: Engine = Bridge.newEngine(this)
    private val diagnostics = DiagnosticsStore(context)

    init {
        runCatching {
            engine.start(context.getDatabasePath("droidzap-session.db").absolutePath)
        }.onSuccess { diagnostics.add("Módulo de protocolo iniciado") }
            .onFailure { update(ProtocolGateway.State.Failed("Falha ao abrir a sessão: ${it.message}")) }
    }

    override fun currentState() = state

    override fun observeState(observer: (ProtocolGateway.State) -> Unit) {
        stateObserver = observer
        observer(state)
    }

    override fun requestQrPairing(onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestQR() }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar QR Code")) }
    }

    override fun requestPhonePairing(phoneE164: String, onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestPhone(phoneE164) }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar código")) }
    }

    override fun onState(protocolState: String?, detail: String?) {
        diagnostics.add("Estado do protocolo: ${protocolState.orEmpty()} — ${detail.orEmpty()}")
        when (protocolState) {
            "connecting" -> update(ProtocolGateway.State.Connecting)
            "connected" -> update(ProtocolGateway.State.Connected)
            "disconnected" -> update(ProtocolGateway.State.Disconnected)
            "error" -> update(ProtocolGateway.State.Failed(detail ?: "Erro de conexão"))
        }
    }

    override fun onQRCode(payload: String?, validForSeconds: Long) {
        if (payload != null) {
            diagnostics.add("Novo QR recebido, validade $validForSeconds segundos")
            update(ProtocolGateway.State.QrReady(payload, System.currentTimeMillis() + validForSeconds * 1000))
        }
    }

    override fun onPairCode(code: String?) {
        if (code != null) {
            diagnostics.add("Código de pareamento por telefone recebido")
            update(ProtocolGateway.State.PairCodeReady(code))
        }
    }

    override fun sendText(chatJid: String, text: String) = engine.sendText(chatJid, text)

    override fun sendVoice(chatJid: String, filePath: String, durationSeconds: Long) =
        engine.sendVoice(chatJid, filePath, durationSeconds)

    override fun observeMessages(observer: (String, String, String, Long) -> Unit) {
        messageObserver = observer
    }

    override fun observeChatActivity(observer: (String, String, String, Boolean) -> Unit) {
        activityObserver = observer
    }

    override fun onMessage(chatJID: String?, senderJID: String?, text: String?, timestamp: Long) {
        diagnostics.add("Mensagem recebida, tipo ${if (text.isNullOrBlank()) "mídia" else "texto"}")
        messageObserver?.invoke(chatJID.orEmpty(), senderJID.orEmpty(), text.orEmpty(), timestamp)
    }

    override fun onChatActivity(chatJID: String?, senderJID: String?, activity: String?, active: Boolean) {
        if (active) diagnostics.add("Atividade recebida: ${activity.orEmpty()}")
        activityObserver?.invoke(chatJID.orEmpty(), senderJID.orEmpty(), activity.orEmpty(), active)
    }

    private fun update(next: ProtocolGateway.State) {
        state = next
        stateObserver?.invoke(next)
        observer?.invoke(next)
    }

    override fun disconnect() { engine.stop() }
}
