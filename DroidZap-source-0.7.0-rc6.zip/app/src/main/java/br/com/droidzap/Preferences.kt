package br.com.droidzap

import android.content.Context

class Preferences(context: Context) {
    private val store = context.getSharedPreferences("droid_zap", Context.MODE_PRIVATE)
    var spokenAlerts: Boolean
        get() = store.getBoolean("spoken", true)
        set(value) = store.edit().putBoolean("spoken", value).apply()
    var vibration: Boolean
        get() = store.getBoolean("vibration", true)
        set(value) = store.edit().putBoolean("vibration", value).apply()
    var keyboardSound: Boolean
        get() = store.getBoolean("keyboard", false)
        set(value) = store.edit().putBoolean("keyboard", value).apply()
    var style: ToneEngine.Style
        get() = runCatching { ToneEngine.Style.valueOf(store.getString("style", "IPHONE_INSPIRED")!!) }
            .getOrDefault(ToneEngine.Style.IPHONE_INSPIRED)
        set(value) = store.edit().putString("style", value.name).apply()

    var privateNotificationChoice: Int
        get() = store.getInt("private_notification_choice", 24).coerceIn(ToneEngine.notificationChoices.indices)
        set(value) = store.edit().putInt("private_notification_choice", value).apply()

    var groupNotificationChoice: Int
        get() = store.getInt("group_notification_choice", 38).coerceIn(ToneEngine.notificationChoices.indices)
        set(value) = store.edit().putInt("group_notification_choice", value).apply()
}
