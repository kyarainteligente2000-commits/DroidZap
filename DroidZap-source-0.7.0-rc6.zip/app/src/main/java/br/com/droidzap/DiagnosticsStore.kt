package br.com.droidzap

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small app-private event log. QR payloads, pair codes and message text are never stored. */
class DiagnosticsStore(context: Context) {
    private val store = context.getSharedPreferences("droid_zap_diagnostics", Context.MODE_PRIVATE)
    private val format = SimpleDateFormat("dd/MM HH:mm:ss", Locale("pt", "BR"))

    @Synchronized
    fun add(event: String) {
        val safe = event.replace(Regex("[\r\n]+"), " ").take(300)
        val entries = lines().toMutableList()
        entries += "${format.format(Date())} — $safe"
        store.edit().putString("events", entries.takeLast(100).joinToString("\n")).apply()
    }

    @Synchronized
    fun text(): String = store.getString("events", "")?.ifBlank { "Nenhum evento registrado" }
        ?: "Nenhum evento registrado"

    @Synchronized
    fun clear() = store.edit().remove("events").apply()

    private fun lines() = store.getString("events", "").orEmpty().lineSequence().filter(String::isNotBlank).toList()
}
