package br.com.droidzap

import android.Manifest
import android.content.pm.PackageManager
import android.content.ClipData
import android.content.ClipboardManager
import android.database.Cursor
import android.provider.ContactsContract
import android.view.accessibility.AccessibilityEvent
import androidx.appcompat.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.widget.*
import android.widget.AdapterView
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var prefs: Preferences
    private val tones = ToneEngine()
    private lateinit var protocol: ProtocolGateway
    private var tts: TextToSpeech? = null
    private var onHomeScreen = true
    private val voiceRecorder by lazy { VoiceRecorder(this) }
    private val updates by lazy { UpdateManager(this) }
    private var recordedVoice: VoiceRecorder.Result? = null
    private var messageLog: LinearLayout? = null
    private var pendingRecordAction: (() -> Unit)? = null
    private var qrImage: ImageView? = null
    private var activityStatus: TextView? = null
    private var homeConnectionStatus: TextView? = null
    private var pendingContactsAction: (() -> Unit)? = null
    private var activeChatJid: String? = null
    private val recentChats = linkedMapOf<String, String>()
    private val activeChatCues = mutableSetOf<String>()
    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingRecordAction?.invoke() else announce("Permissão do microfone negada")
        pendingRecordAction = null
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingContactsAction?.invoke() else announce("Permissão para acessar contatos negada")
        pendingContactsAction = null
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        prefs = Preferences(this)
        protocol = NativeProtocolGateway(this)
        protocol.observeState { state -> runOnUiThread {
            val label = stateLabel(state)
            homeConnectionStatus?.text = "Conexão: $label"
            homeConnectionStatus?.contentDescription = "Estado da conexão: $label"
        } }
        protocol.observeMessages { chat, sender, text, _ ->
            runOnUiThread {
                val jid = chat.ifBlank { sender }
                val isGroup = jid.endsWith("@g.us")
                val label = if (isGroup) "Grupo ${jid.substringBefore('@')}"
                    else contactNameForJid(jid) ?: sender.substringBefore('@')
                recentChats[jid] = label
                if (activeChatJid == jid) appendMessage("$label: ${text.ifBlank { "conteúdo não textual" }}")
                val choiceIndex = if (isGroup) prefs.groupNotificationChoice else prefs.privateNotificationChoice
                val choice = ToneEngine.notificationChoices[choiceIndex]
                tones.messageReceived(choice.style, choice.variant)
                vibrateCue()
                if (activeChatJid != jid) announce("Nova mensagem de $label")
            }
        }
        protocol.observeChatActivity { _, sender, activity, active ->
            runOnUiThread {
                val person = sender.substringBefore('@').ifBlank { "Contato" }
                val message = when {
                    !active -> ""
                    activity == "recording" -> "$person está gravando áudio"
                    else -> "$person está digitando"
                }
                activityStatus?.text = message
                activityStatus?.contentDescription = message
                val cueKey = "$sender:$activity"
                if (!active) activeChatCues.remove(cueKey)
                else if (activeChatCues.add(cueKey)) {
                    vibrateCue()
                    if (activity == "recording") tones.contactRecording(prefs.style)
                    else tones.contactTyping(prefs.style)
                    if (prefs.spokenAlerts) speak(message)
                }
            }
        }
        tts = TextToSpeech(this, this)
        onBackPressedDispatcher.addCallback(this) { if (onHomeScreen) finish() else showHome() }
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 24f; contentDescription = title
                isAccessibilityHeading = true
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; contentDescription = label; setOnClickListener { action() }
    }

    private fun showHome() {
        onHomeScreen = true
        activeChatJid = null
        base("Droid Zap 0.7 RC4")
        homeConnectionStatus = TextView(this).apply {
            text = "Conexão: ${stateLabel(protocol.currentState())}"
            contentDescription = "Estado da conexão: ${stateLabel(protocol.currentState())}"
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(homeConnectionStatus)
        root.addView(button("Nova conversa") { requestContacts { showNewConversation() } })
        if (recentChats.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "Nenhuma conversa nesta sessão"
                contentDescription = text
            })
        } else {
            root.addView(TextView(this).apply {
                text = "Conversas recentes"
                contentDescription = text
                isAccessibilityHeading = true
            })
            recentChats.forEach { (jid, name) ->
                root.addView(button("Abrir conversa com $name") { showChat(name, jid) })
            }
        }
        root.addView(TextView(this).apply {
            text = "Mais opções"
            contentDescription = text
            isAccessibilityHeading = true
        })
        root.addView(button("Parear aparelho") { showPairing() })
        root.addView(button("Configurações de acessibilidade e sons") { showSettings() })
        root.addView(button("Procurar atualização") { checkForUpdate() })
        root.addView(button("Diagnóstico e relatório de conexão") { showDiagnostics() })
    }

    private fun showDiagnostics() {
        onHomeScreen = false
        base("Diagnóstico e relatório de conexão")
        val diagnostics = DiagnosticsStore(this)
        val report = TextView(this).apply {
            text = diagnostics.text()
            contentDescription = "Relatório de diagnóstico. $text"
            setTextIsSelectable(true)
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(report)
        root.addView(button("Copiar relatório") {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Relatório do Droid Zap", report.text))
            announce("Relatório copiado")
        })
        root.addView(button("Apagar relatório") {
            diagnostics.clear(); report.text = "Nenhum evento registrado"
            announce("Relatório apagado")
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun checkForUpdate() {
        announce("Procurando atualização")
        val current = packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0"
        updates.check(current) { result -> runOnUiThread {
            result.onFailure { announce("Não foi possível procurar atualização: ${it.message}") }
                .onSuccess { release ->
                    if (release == null) announce("O Droid Zap já está atualizado")
                    else AlertDialog.Builder(this)
                        .setTitle("Atualização disponível")
                        .setMessage("Versão ${release.version}. Deseja baixar e abrir o instalador?")
                        .setPositiveButton("Baixar") { _, _ -> updates.downloadAndInstall(release, ::announce) }
                        .setNegativeButton("Agora não", null)
                        .show()
                }
        } }
    }

    private fun showConversations() {
        showHome()
    }

    private fun requestContacts(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) action()
        else {
            pendingContactsAction = action
            contactsPermission.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private data class DeviceContact(val name: String, val number: String)

    private fun readContacts(): List<DeviceContact> {
        val result = linkedMapOf<String, DeviceContact>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val cursor: Cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY + " COLLATE LOCALIZED ASC"
        ) ?: return emptyList()
        cursor.use {
            val nameColumn = it.getColumnIndexOrThrow(projection[0])
            val numberColumn = it.getColumnIndexOrThrow(projection[1])
            while (it.moveToNext()) {
                val name = it.getString(nameColumn)?.trim().orEmpty()
                val digits = normalizePhone(it.getString(numberColumn).orEmpty())
                if (name.isNotBlank() && digits.length >= 10) result.putIfAbsent(digits, DeviceContact(name, digits))
            }
        }
        return result.values.toList()
    }

    private fun showNewConversation() {
        onHomeScreen = false
        base("Nova conversa")
        val contacts = readContacts()
        if (contacts.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "Nenhum contato com telefone foi encontrado. Confirme se os contatos Google estão sincronizados nas configurações do Android."
                contentDescription = text
            })
        } else {
            root.addView(TextView(this).apply {
                text = "${contacts.size} contatos encontrados. Escolha um contato."
                contentDescription = text
                accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            })
            contacts.forEach { contact ->
                root.addView(button(contact.name) {
                    val jid = "${contact.number}@s.whatsapp.net"
                    recentChats[jid] = contact.name
                    showChat(contact.name, jid)
                })
            }
        }
        root.addView(button("Digitar outro número") { showChat("Novo número", null) })
        root.addView(button("Voltar para conversas") { showConversations() })
    }

    private fun showChat(contactName: String, initialJid: String?) {
        onHomeScreen = false
        activeChatJid = initialJid
        base("Conversa com $contactName")
        val recipient = EditText(this).apply {
            hint = "Número com país e DDD"
            contentDescription = "Número do destinatário com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
            visibility = if (initialJid == null) View.VISIBLE else View.GONE
        }
        val message = EditText(this).apply {
            hint = "Digite uma mensagem"
            contentDescription = "Mensagem"
            minLines = 2
            doAfterTextChanged { if (prefs.keyboardSound && !it.isNullOrEmpty()) tones.keyboardClick(prefs.style) }
        }
        root.addView(recipient)
        root.addView(message)
        activityStatus = TextView(this).apply {
            text = ""; contentDescription = ""
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(activityStatus)
        root.addView(button("Enviar mensagem") {
            val jid = activeChatJid ?: recipientJid(recipient) ?: return@button
            activeChatJid = jid
            recentChats[jid] = contactName
            val body = message.text.toString().trim()
            if (body.isBlank()) { announce("Digite uma mensagem"); return@button }
            runProtocol("Enviando mensagem", "Mensagem enviada", {
                appendMessage("Você: $body")
                message.text.clear()
                tones.messageSent(prefs.style)
            }) { protocol.sendText(jid, body) }
        })

        val recordButton = button("Iniciar gravação de voz") {}
        var recording = false
        recordButton.setOnClickListener {
            if (!recording) {
                requestMicrophone {
                    recordButton.isEnabled = false
                    tones.recordingStarted(prefs.style)
                    // Start after the cue so it is audible and is not captured in the voice note.
                    recordButton.postDelayed({
                        runCatching { voiceRecorder.start() }.onSuccess {
                            recording = true
                            recordedVoice = null
                            recordButton.text = "Parar gravação"
                            recordButton.contentDescription = "Parar gravação de voz"
                            announce("Gravação iniciada")
                        }.onFailure { announce("Não foi possível iniciar a gravação: ${it.message}") }
                        recordButton.isEnabled = true
                    }, 350)
                }
            } else {
                runCatching { voiceRecorder.stop() }.onSuccess {
                    tones.recordingFinished(prefs.style)
                    recording = false
                    recordedVoice = it
                    recordButton.text = "Gravar novamente"
                    recordButton.contentDescription = "Gravar novamente"
                    announce("Gravação concluída, duração ${it.durationSeconds} segundos")
                }.onFailure { announce("Falha ao finalizar a gravação: ${it.message}") }
            }
        }
        root.addView(recordButton)
        root.addView(button("Ouvir gravação") {
            val voice = recordedVoice ?: run { announce("Nenhuma gravação disponível"); return@button }
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                setDataSource(voice.file.absolutePath)
                setVolume(1f, 1f)
                setOnCompletionListener { it.release(); announce("Fim da gravação") }
                prepare(); start()
            }
            announce("Reproduzindo gravação")
        })
        root.addView(button("Enviar gravação") {
            val jid = activeChatJid ?: recipientJid(recipient) ?: return@button
            activeChatJid = jid
            recentChats[jid] = contactName
            val voice = recordedVoice ?: run { announce("Grave um áudio primeiro"); return@button }
            runProtocol("Enviando gravação", "Gravação enviada") {
                protocol.sendVoice(jid, voice.file.absolutePath, voice.durationSeconds)
            }
        })
        root.addView(button("Cancelar e apagar gravação") {
            voiceRecorder.cancel(); recordedVoice?.file?.delete(); recordedVoice = null
            recording = false; recordButton.text = "Iniciar gravação de voz"
            announce("Gravação apagada")
        })
        root.addView(TextView(this).apply {
            text = "Mensagens desta sessão"; isAccessibilityHeading = true
        })
        messageLog = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(messageLog)
        root.addView(button("Voltar para conversas") { if (recording) voiceRecorder.cancel(); showConversations() })
    }

    private fun recipientJid(field: EditText): String? {
        val digits = normalizePhone(field.text.toString())
        if (digits.length < 10) { announce("Digite o número com país e DDD"); return null }
        return "$digits@s.whatsapp.net"
    }

    private fun normalizePhone(value: String): String {
        val digits = value.filter(Char::isDigit)
        return if (digits.length == 10 || digits.length == 11) "55$digits" else digits
    }

    private fun contactNameForJid(jid: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val digits = jid.substringBefore('@').filter(Char::isDigit)
        return readContacts().firstOrNull { contact ->
            contact.number.endsWith(digits) || digits.endsWith(contact.number)
        }?.name
    }

    private fun appendMessage(accessibleText: String) {
        messageLog?.addView(TextView(this).apply { text = accessibleText; contentDescription = accessibleText })
        messageLog?.announceForAccessibility(accessibleText)
    }

    private fun runProtocol(start: String, success: String, onSuccess: () -> Unit = {}, action: () -> Unit) {
        announce(start)
        Thread {
            runCatching(action).onSuccess { runOnUiThread { onSuccess(); announce(success) } }
                .onFailure { runOnUiThread { announce("Falha: ${it.message ?: "erro desconhecido"}") } }
        }.start()
    }

    private fun requestMicrophone(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingRecordAction = action; microphonePermission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun vibrateCue() {
        if (!prefs.vibration) return
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        }
        if (vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun showPairing() {
        onHomeScreen = false
        base("Parear aparelho")
        val status = TextView(this).apply {
            text = "Escolha pareamento por QR Code ou telefone"; contentDescription = text
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        }
        root.addView(status)
        root.addView(button("Gerar QR Code") {
            status.text = "Solicitando novo QR Code"
            protocol.requestQrPairing { state -> runOnUiThread { renderProtocolState(state, status) } }
        })
        val phone = EditText(this).apply {
            hint = "Número com país e DDD, por exemplo 5511999999999"
            contentDescription = "Número de telefone com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(phone)
        root.addView(button("Gerar código por telefone") {
            val normalized = normalizePhone(phone.text.toString())
            if (normalized.length < 10) announce("Digite um número válido com código do país e DDD")
            else protocol.requestPhonePairing(normalized) { state ->
                runOnUiThread { renderProtocolState(state, status) }
            }
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun renderProtocolState(state: ProtocolGateway.State, status: TextView) {
        val message = when (state) {
            ProtocolGateway.State.Disconnected -> stateLabel(state)
            ProtocolGateway.State.Connecting -> stateLabel(state)
            is ProtocolGateway.State.QrReady -> {
                showQrCode(state.payload)
                "Novo QR Code disponível"
            }
            is ProtocolGateway.State.PairCodeReady -> {
                val spokenCode = state.code.filter(Char::isLetterOrDigit).replace("", " ").trim()
                "Código de pareamento. $spokenCode. Toque duas vezes para selecionar e copiar."
            }
            ProtocolGateway.State.Connected -> stateLabel(state)
            is ProtocolGateway.State.Failed -> state.accessibleMessage
        }
        status.text = message
        status.contentDescription = message
        status.isFocusable = true
        status.isClickable = state is ProtocolGateway.State.PairCodeReady
        status.setOnClickListener(if (state is ProtocolGateway.State.PairCodeReady) View.OnClickListener {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("Código de pareamento", state.code))
            announce("Código de pareamento copiado")
        } else null)
        status.postDelayed({
            status.requestFocus()
            status.sendAccessibilityEvent(AccessibilityEvent.TYPE_ANNOUNCEMENT)
            announce(message)
        }, 350)
    }

    private fun stateLabel(state: ProtocolGateway.State): String = when (state) {
        ProtocolGateway.State.Disconnected -> "desconectado"
        ProtocolGateway.State.Connecting -> "conectando"
        is ProtocolGateway.State.QrReady -> "aguardando leitura do QR Code"
        is ProtocolGateway.State.PairCodeReady -> "aguardando confirmação do código"
        ProtocolGateway.State.Connected -> "conta conectada"
        is ProtocolGateway.State.Failed -> "erro: ${state.accessibleMessage}"
    }

    private fun showQrCode(payload: String) {
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 720, 720)
        val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
        for (x in 0 until matrix.width) for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
        qrImage?.let(root::removeView)
        qrImage = ImageView(this).apply {
            setImageBitmap(bitmap)
            contentDescription = "QR Code de vinculação do Droid Zap. Use o WhatsApp principal para escanear."
            adjustViewBounds = true
        }
        root.addView(qrImage, 2)
    }

    private fun showSettings() {
        onHomeScreen = false
        base("Configurações")
        fun option(label: String, checked: Boolean, update: (Boolean) -> Unit) = CheckBox(this).apply {
            text = label; isChecked = checked; contentDescription = label
            setOnCheckedChangeListener { _, value -> update(value) }
        }
        root.addView(option("Falar quando alguém estiver digitando ou gravando", prefs.spokenAlerts) { prefs.spokenAlerts = it })
        root.addView(option("Vibrar nos avisos", prefs.vibration) { prefs.vibration = it })
        root.addView(option("Som ao digitar", prefs.keyboardSound) { prefs.keyboardSound = it })
        root.addView(button("Notificações") { showNotificationSettings() })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ToneEngine.Style.entries.map { it.label })
            setSelection(ToneEngine.Style.entries.indexOf(prefs.style)); contentDescription = "Categoria de som"
        }
        root.addView(spinner)
        root.addView(button("Ouvir amostra") {
            prefs.style = ToneEngine.Style.entries[spinner.selectedItemPosition]
            tones.play(prefs.style); announce("Amostra ${prefs.style.label}")
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun showNotificationSettings() {
        onHomeScreen = false
        base("Notificações")
        val choices = ToneEngine.notificationChoices
        val labels = choices.map { it.label }

        fun toneSelector(title: String, initial: Int, save: (Int) -> Unit) {
            root.addView(TextView(this).apply {
                text = title
                contentDescription = title
                isAccessibilityHeading = true
            })
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                setSelection(initial)
                contentDescription = "$title. Escolha entre ${choices.size} toques originais"
            }
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    save(position)
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
            root.addView(spinner)
            root.addView(button("Ouvir amostra de $title") {
                val choice = choices[spinner.selectedItemPosition]
                tones.messageReceived(choice.style, choice.variant)
                announce("Amostra ${choice.label}")
            })
        }

        toneSelector("Mensagens privadas", prefs.privateNotificationChoice) {
            prefs.privateNotificationChoice = it
        }
        toneSelector("Mensagens de grupos", prefs.groupNotificationChoice) {
            prefs.groupNotificationChoice = it
        }
        root.addView(TextView(this).apply {
            text = "Os 48 toques são criações originais do Droid Zap, organizados em oito categorias."
            contentDescription = text
        })
        root.addView(button("Voltar para configurações") { showSettings() })
    }

    private fun announce(message: String) {
        window.decorView.announceForAccessibility(message)
    }

    private fun speak(message: String) {
        announce(message)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "droid_zap_activity")
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR") }
    override fun onDestroy() { voiceRecorder.cancel(); protocol.disconnect(); tts?.shutdown(); super.onDestroy() }
}
