// Package bridge exposes a gomobile-compatible API for the Droid Zap UI.
package bridge

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"go.mau.fi/whatsmeow"
	waE2E "go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	"google.golang.org/protobuf/proto"
)

type Listener interface {
	OnState(state string, detail string)
	OnQRCode(payload string, validForSeconds int64)
	OnPairCode(code string)
	OnMessage(chatJID string, senderJID string, text string, timestamp int64)
}

type Engine struct {
	mu        sync.Mutex
	client    *whatsmeow.Client
	container *sqlstore.Container
	listener  Listener
	cancel    context.CancelFunc
	running   bool
}

func NewEngine(listener Listener) *Engine { return &Engine{listener: listener} }

func (e *Engine) emit(state, detail string) {
	if e.listener != nil {
		e.listener.OnState(state, detail)
	}
}

// Start opens (or creates) the encrypted-session database in Android app-private storage.
// Android is responsible for protecting the containing directory and backup policy.
func (e *Engine) Start(databasePath string) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.client != nil {
		return nil
	}
	db, err := sql.Open("sqlite3", "file:"+databasePath+"?_foreign_keys=on")
	if err != nil {
		return fmt.Errorf("open session database: %w", err)
	}
	container := sqlstore.NewWithDB(db, "sqlite3", nil)
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	if err = container.Upgrade(ctx); err != nil {
		_ = db.Close()
		return fmt.Errorf("upgrade session database: %w", err)
	}
	device, err := container.GetFirstDevice(ctx)
	if err != nil {
		_ = container.Close()
		return fmt.Errorf("load session: %w", err)
	}
	client := whatsmeow.NewClient(device, nil)
	client.AddEventHandler(e.handleEvent)
	e.container, e.client = container, client
	if device.ID != nil {
		go func() {
			e.emit("connecting", "Restaurando sessão")
			if connectErr := client.Connect(); connectErr != nil {
				e.emit("error", connectErr.Error())
			}
		}()
	}
	return nil
}

func (e *Engine) RequestQR() error { return e.startPairing("") }

func (e *Engine) RequestPhone(phone string) error {
	phone = strings.TrimPrefix(strings.TrimSpace(phone), "+")
	if len(phone) < 10 {
		return errors.New("número deve incluir país e DDD")
	}
	return e.startPairing(phone)
}

func (e *Engine) startPairing(phone string) error {
	e.mu.Lock()
	if e.client == nil {
		e.mu.Unlock()
		return errors.New("módulo não iniciado")
	}
	if e.client.Store.ID != nil {
		e.mu.Unlock()
		return errors.New("já existe uma conta pareada")
	}
	if e.running {
		e.mu.Unlock()
		return errors.New("pareamento já está em andamento")
	}
	ctx, cancel := context.WithCancel(context.Background())
	e.cancel, e.running = cancel, true
	client := e.client
	e.mu.Unlock()
	go e.pairLoop(ctx, client, phone)
	return nil
}

func (e *Engine) pairLoop(ctx context.Context, client *whatsmeow.Client, phone string) {
	defer func() { e.mu.Lock(); e.running = false; e.mu.Unlock() }()
	for ctx.Err() == nil && client.Store.ID == nil {
		qrChannel, err := client.GetQRChannel(ctx)
		if err != nil {
			e.emit("error", err.Error())
			return
		}
		e.emit("connecting", "Solicitando pareamento")
		if err = client.Connect(); err != nil {
			e.emit("error", err.Error())
			return
		}
		phoneRequested := false
		paired := false
		for item := range qrChannel {
			switch item.Event {
			case "code":
				if phone != "" && !phoneRequested {
					phoneRequested = true
					code, pairErr := client.PairPhone(ctx, phone, true, whatsmeow.PairClientAndroid, "Chrome (Android)")
					if pairErr != nil {
						e.emit("error", pairErr.Error())
						return
					}
					if e.listener != nil {
						e.listener.OnPairCode(code)
					}
					e.emit("pair_code", "Código por telefone disponível")
				} else if phone == "" && e.listener != nil {
					e.listener.OnQRCode(item.Code, int64(item.Timeout/time.Second))
					e.emit("qr", "Novo QR Code disponível")
				}
			case "success":
				paired = true
				e.emit("connected", "Conta vinculada")
			case "timeout":
				e.emit("refreshing_qr", "QR expirado; solicitando outro")
			default:
				if item.Error != nil {
					e.emit("error", item.Error.Error())
				}
			}
		}
		if paired || client.Store.ID != nil || ctx.Err() != nil {
			return
		}
		client.Disconnect()
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Second):
		}
	}
}

func (e *Engine) SendText(chatJID, text string) error {
	e.mu.Lock()
	client := e.client
	e.mu.Unlock()
	if client == nil || !client.IsConnected() {
		return errors.New("conta desconectada")
	}
	jid, err := types.ParseJID(chatJID)
	if err != nil {
		return fmt.Errorf("destino inválido: %w", err)
	}
	text = strings.TrimSpace(text)
	if text == "" {
		return errors.New("mensagem vazia")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	_, err = client.SendMessage(ctx, jid, &waE2E.Message{Conversation: proto.String(text)})
	return err
}

// SendVoice uploads an Android-recorded Ogg/Opus file and sends it as a push-to-talk message.
func (e *Engine) SendVoice(chatJID, filePath string, durationSeconds int64) error {
	e.mu.Lock()
	client := e.client
	e.mu.Unlock()
	if client == nil || !client.IsConnected() {
		return errors.New("conta desconectada")
	}
	jid, err := types.ParseJID(chatJID)
	if err != nil {
		return fmt.Errorf("destino inválido: %w", err)
	}
	data, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("ler gravação: %w", err)
	}
	if len(data) == 0 {
		return errors.New("gravação vazia")
	}
	if durationSeconds < 1 {
		durationSeconds = 1
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	upload, err := client.Upload(ctx, data, whatsmeow.MediaAudio)
	if err != nil {
		return fmt.Errorf("enviar áudio: %w", err)
	}
	seconds := uint32(durationSeconds)
	voice := &waE2E.AudioMessage{
		URL: &upload.URL, DirectPath: &upload.DirectPath,
		MediaKey: upload.MediaKey, FileEncSHA256: upload.FileEncSHA256,
		FileSHA256: upload.FileSHA256, FileLength: &upload.FileLength,
		Mimetype: proto.String("audio/ogg; codecs=opus"), Seconds: &seconds,
		PTT: proto.Bool(true),
	}
	_, err = client.SendMessage(ctx, jid, &waE2E.Message{AudioMessage: voice})
	return err
}

func (e *Engine) handleEvent(raw any) {
	switch evt := raw.(type) {
	case *events.Connected:
		e.emit("connected", "Conta conectada")
	case *events.Disconnected:
		e.emit("disconnected", "Conta desconectada")
	case *events.Message:
		if e.listener == nil {
			return
		}
		text := evt.Message.GetConversation()
		if text == "" {
			text = evt.Message.GetExtendedTextMessage().GetText()
		}
		e.listener.OnMessage(evt.Info.Chat.String(), evt.Info.Sender.String(), text, evt.Info.Timestamp.Unix())
	}
}

func (e *Engine) Stop() {
	e.mu.Lock()
	if e.cancel != nil {
		e.cancel()
	}
	if e.client != nil {
		e.client.Disconnect()
	}
	if e.container != nil {
		_ = e.container.Close()
	}
	e.client, e.container, e.cancel, e.running = nil, nil, nil, false
	e.mu.Unlock()
}
