package br.com.droidzap

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Environment
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class UpdateManager(private val context: Context) {
    data class Release(val version: String, val apkUrl: String, val pageUrl: String)

    fun check(currentVersion: String, result: (Result<Release?>) -> Unit) = Thread {
        result(runCatching {
            val connection = URL(RELEASES_API).openConnection() as HttpURLConnection
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("Accept", "application/vnd.github+json")
            connection.setRequestProperty("User-Agent", "DroidZap-Android")
            try {
                check(connection.responseCode in 200..299) { "GitHub respondeu ${connection.responseCode}" }
                val releases = JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
                (0 until releases.length()).asSequence().map { releases.getJSONObject(it) }
                    .filter { !it.optBoolean("draft") }
                    .mapNotNull { release ->
                        val tag = release.optString("tag_name").trimStart('v')
                        val assets = release.optJSONArray("assets") ?: return@mapNotNull null
                        val apk = (0 until assets.length()).asSequence().map { assets.getJSONObject(it) }
                            .firstOrNull { it.optString("name").endsWith(".apk", true) }
                            ?: return@mapNotNull null
                        Release(tag, apk.getString("browser_download_url"), release.getString("html_url"))
                    }.firstOrNull { isNewer(it.version, currentVersion) }
            } finally { connection.disconnect() }
        })
    }.start()

    fun downloadAndInstall(release: Release, status: (String) -> Unit) {
        val fileName = "DroidZap-${release.version}.apk"
        val destination = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        destination.delete()
        val request = DownloadManager.Request(Uri.parse(release.apkUrl))
            .setTitle("Atualização do Droid Zap")
            .setDescription("Baixando versão ${release.version}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        val manager = context.getSystemService(DownloadManager::class.java)
        val id = manager.enqueue(request)
        status("Atualização ${release.version} em download")
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context, intent: Intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return
                runCatching {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", destination)
                    context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                }.onFailure { status("Download concluído, mas não foi possível abrir o instalador") }
                context.unregisterReceiver(this)
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
    }

    private fun isNewer(candidate: String, current: String): Boolean {
        fun numbers(value: String) = value.substringBefore('-').split('.').map { it.toIntOrNull() ?: 0 }
        val a = numbers(candidate); val b = numbers(current)
        for (index in 0 until maxOf(a.size, b.size)) {
            val difference = a.getOrElse(index) { 0 }.compareTo(b.getOrElse(index) { 0 })
            if (difference != 0) return difference > 0
        }
        return !candidate.contains("dev", true) && current.contains("dev", true)
    }

    companion object {
        private const val RELEASES_API = "https://api.github.com/repos/kyarainteligente2000-commits/DroidZap/releases?per_page=10"
    }
}
