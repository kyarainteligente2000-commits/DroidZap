package br.com.droidzap

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import java.util.concurrent.atomic.AtomicInteger

/** Creates short, original tones at runtime; no manufacturer audio is copied. */
class ToneEngine {
    enum class Style(
        val label: String,
        val base: Double,
        val harmonic: Double,
        val decay: Double
    ) {
        IPHONE_INSPIRED("Inspirado em iPhone — original", 1318.5, .12, 15.0),
        SAMSUNG_INSPIRED("Inspirado em Samsung — original", 987.8, .27, 11.0),
        XIAOMI_INSPIRED("Inspirado em Xiaomi — original", 784.0, .34, 9.0),
        MOTOROLA_INSPIRED("Inspirado em Motorola — original", 523.3, .42, 13.0),
        CRISTAL("Droid Zap Cristal", 1046.5, .20, 12.0),
        SUAVE("Droid Zap Suave", 659.3, .08, 8.0),
        PULSO("Droid Zap Pulso", 440.0, .48, 17.0),
        MINIMAL("Droid Zap Minimalista", 880.0, .05, 20.0)
    }

    private val rotation = AtomicInteger(0)

    /** Six compositions per category: 48 notification combinations in total. */
    fun play(style: Style, variant: Int = -1, volume: Float = .32f) = thread {
        val selected = if (variant < 0) Math.floorMod(rotation.getAndIncrement(), 6) else variant % 6
        val rate = 44_100
        val duration = when (selected) { 1, 4 -> .25; 3 -> .30; else -> .17 }
        val count = (rate * duration).toInt()
        val data = ShortArray(count)
        val intervals = doubleArrayOf(1.0, 1.125, 1.25, .75, 1.5, .875)
        val frequency = style.base * intervals[selected]
        for (i in data.indices) {
            val time = i.toDouble() / rate
            val secondNote = selected == 1 || selected == 3 || selected == 4
            val noteFrequency = if (secondNote && time > duration * .52)
                frequency * if (selected == 3) .8 else 1.25 else frequency
            val pulse = if (selected == 5) .72 + .28 * sin(2 * PI * 18 * time) else 1.0
            val envelope = exp(-time * (style.decay + selected * .55))
            val wave = (sin(2 * PI * noteFrequency * time) +
                style.harmonic * sin(2 * PI * noteFrequency * 2.01 * time) +
                style.harmonic * .3 * sin(2 * PI * noteFrequency * 3.0 * time)) * pulse
            data[i] = (wave * envelope * Short.MAX_VALUE * volume).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(data.size * 2).build()
        track.write(data, 0, data.size)
        track.play()
        Thread.sleep((duration * 1000).toLong() + 30)
        track.release()
    }

    fun keyboardClick(style: Style) = play(style, 5, .10f)
}
