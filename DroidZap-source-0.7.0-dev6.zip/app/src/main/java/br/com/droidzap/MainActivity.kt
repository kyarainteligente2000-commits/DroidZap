package br.com.droidzap

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AlertDialog
import android.os.Bundle
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.view.HapticFeedbackConstants
import android.widget.*
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var prefs: Preferences
    private val tones = ToneEngine()
    private lateinit var protocol: ProtocolGateway
    private var tts: TextToSpeech? = null
    private var onHomeScreen = true
    private val voiceRecorder by lazy { VoiceRecorder(this) }
    private val updates by lazy { UpdateManager(this) }
    private var recordedVoice: VoiceRecorder.Result? = null
    private var messageLog: LinearLayout? = null
    private var pendingRecordAction: (() -> Unit)? = null
    private var qrImage: ImageView? = null
    private var activityStatus: TextView? = null
    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingRecordAction?.invoke() else announce("Permissão do microfone negada")
        pendingRecordAction = null
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        prefs = Preferences(this)
        protocol = NativeProtocolGateway(this)
        protocol.observeMessages { _, sender, text, _ ->
            runOnUiThread { appendMessage("Mensagem recebida de ${sender.substringBefore('@')}: ${text.ifBlank { "conteúdo não textual" }}") }
        }
        protocol.observeChatActivity { _, sender, activity, active ->
            runOnUiThread {
                val person = sender.substringBefore('@').ifBlank { "Contato" }
                val message = when {
                    !active -> ""
                    activity == "recording" -> "$person está gravando áudio"
                    else -> "$person está digitando"
                }
                activityStatus?.text = message
                activityStatus?.contentDescription = message
                if (active) {
                    if (prefs.vibration) window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    if (prefs.spokenAlerts) announce(message)
                }
            }
        }
        tts = TextToSpeech(this, this)
        onBackPressedDispatcher.addCallback(this) { if (onHomeScreen) finish() else showHome() }
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 24f; contentDescription = title
                isAccessibilityHeading = true
            })
        }
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; contentDescription = label; setOnClickListener { action() }
    }

    private fun showHome() {
        onHomeScreen = true
        base("Droid Zap 0.7")
        root.addView(TextView(this).apply {
            text = "Cliente Android nativo experimental, sem chamadas"; contentDescription = text
        })
        root.addView(button("Parear aparelho") { showPairing() })
        root.addView(button("Conversas e mensagens") { showConversation() })
        root.addView(button("Configurações de acessibilidade e sons") { showSettings() })
        root.addView(button("Procurar atualização") { checkForUpdate() })
    }

    private fun checkForUpdate() {
        announce("Procurando atualização")
        val current = packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0"
        updates.check(current) { result -> runOnUiThread {
            result.onFailure { announce("Não foi possível procurar atualização: ${it.message}") }
                .onSuccess { release ->
                    if (release == null) announce("O Droid Zap já está atualizado")
                    else AlertDialog.Builder(this)
                        .setTitle("Atualização disponível")
                        .setMessage("Versão ${release.version}. Deseja baixar e abrir o instalador?")
                        .setPositiveButton("Baixar") { _, _ -> updates.downloadAndInstall(release, ::announce) }
                        .setNegativeButton("Agora não", null)
                        .show()
                }
        } }
    }

    private fun showConversation() {
        onHomeScreen = false
        base("Conversas e mensagens")
        val recipient = EditText(this).apply {
            hint = "Número com país e DDD"
            contentDescription = "Número do destinatário com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        val message = EditText(this).apply {
            hint = "Digite uma mensagem"
            contentDescription = "Mensagem"
            minLines = 2
            doAfterTextChanged { if (prefs.keyboardSound && !it.isNullOrEmpty()) tones.keyboardClick(prefs.style) }
        }
        root.addView(recipient)
        root.addView(message)
        activityStatus = TextView(this).apply {
            text = ""; contentDescription = ""
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(activityStatus)
        root.addView(button("Enviar mensagem") {
            val jid = recipientJid(recipient) ?: return@button
            val body = message.text.toString().trim()
            if (body.isBlank()) { announce("Digite uma mensagem"); return@button }
            runProtocol("Enviando mensagem", "Mensagem enviada") { protocol.sendText(jid, body) }
            appendMessage("Você: $body")
            message.text.clear()
        })

        val recordButton = button("Iniciar gravação de voz") {}
        var recording = false
        recordButton.setOnClickListener {
            if (!recording) {
                requestMicrophone {
                    runCatching { voiceRecorder.start() }.onSuccess {
                        recording = true
                        recordedVoice = null
                        recordButton.text = "Parar gravação"
                        recordButton.contentDescription = "Parar gravação de voz"
                        announce("Gravação iniciada")
                    }.onFailure { announce("Não foi possível iniciar a gravação: ${it.message}") }
                }
            } else {
                runCatching { voiceRecorder.stop() }.onSuccess {
                    recording = false
                    recordedVoice = it
                    recordButton.text = "Gravar novamente"
                    recordButton.contentDescription = "Gravar novamente"
                    announce("Gravação concluída, duração ${it.durationSeconds} segundos")
                }.onFailure { announce("Falha ao finalizar a gravação: ${it.message}") }
            }
        }
        root.addView(recordButton)
        root.addView(button("Ouvir gravação") {
            val voice = recordedVoice ?: run { announce("Nenhuma gravação disponível"); return@button }
            MediaPlayer().apply {
                setDataSource(voice.file.absolutePath)
                setOnCompletionListener { it.release(); announce("Fim da gravação") }
                prepare(); start()
            }
            announce("Reproduzindo gravação")
        })
        root.addView(button("Enviar gravação") {
            val jid = recipientJid(recipient) ?: return@button
            val voice = recordedVoice ?: run { announce("Grave um áudio primeiro"); return@button }
            runProtocol("Enviando gravação", "Gravação enviada") {
                protocol.sendVoice(jid, voice.file.absolutePath, voice.durationSeconds)
            }
        })
        root.addView(button("Cancelar e apagar gravação") {
            voiceRecorder.cancel(); recordedVoice?.file?.delete(); recordedVoice = null
            recording = false; recordButton.text = "Iniciar gravação de voz"
            announce("Gravação apagada")
        })
        root.addView(TextView(this).apply {
            text = "Mensagens desta sessão"; isAccessibilityHeading = true
        })
        messageLog = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        root.addView(messageLog)
        root.addView(button("Voltar") { if (recording) voiceRecorder.cancel(); showHome() })
    }

    private fun recipientJid(field: EditText): String? {
        val digits = field.text.toString().filter(Char::isDigit)
        if (digits.length < 10) { announce("Digite o número com país e DDD"); return null }
        return "$digits@s.whatsapp.net"
    }

    private fun appendMessage(accessibleText: String) {
        messageLog?.addView(TextView(this).apply { text = accessibleText; contentDescription = accessibleText })
        messageLog?.announceForAccessibility(accessibleText)
    }

    private fun runProtocol(start: String, success: String, action: () -> Unit) {
        announce(start)
        Thread {
            runCatching(action).onSuccess { runOnUiThread { announce(success) } }
                .onFailure { runOnUiThread { announce("Falha: ${it.message ?: "erro desconhecido"}") } }
        }.start()
    }

    private fun requestMicrophone(action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) action()
        else { pendingRecordAction = action; microphonePermission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    private fun showPairing() {
        onHomeScreen = false
        base("Parear aparelho")
        val status = TextView(this).apply {
            text = "Escolha pareamento por QR Code ou telefone"; contentDescription = text
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        }
        root.addView(status)
        root.addView(button("Gerar QR Code") {
            status.text = "Solicitando novo QR Code"
            protocol.requestQrPairing { state -> runOnUiThread { renderProtocolState(state, status) } }
        })
        val phone = EditText(this).apply {
            hint = "Número com país e DDD, por exemplo 5511999999999"
            contentDescription = "Número de telefone com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(phone)
        root.addView(button("Gerar código por telefone") {
            val normalized = phone.text.toString().filter(Char::isDigit)
            if (normalized.length < 10) announce("Digite um número válido com código do país e DDD")
            else protocol.requestPhonePairing(normalized) { state ->
                runOnUiThread { renderProtocolState(state, status) }
            }
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun renderProtocolState(state: ProtocolGateway.State, status: TextView) {
        val message = when (state) {
            ProtocolGateway.State.Disconnected -> "Desconectado"
            ProtocolGateway.State.Connecting -> "Conectando"
            is ProtocolGateway.State.QrReady -> {
                showQrCode(state.payload)
                "Novo QR Code disponível"
            }
            is ProtocolGateway.State.PairCodeReady -> "Código de pareamento: ${state.code}"
            ProtocolGateway.State.Connected -> "Conta conectada"
            is ProtocolGateway.State.Failed -> state.accessibleMessage
        }
        status.text = message
        announce(message)
    }

    private fun showQrCode(payload: String) {
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 720, 720)
        val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
        for (x in 0 until matrix.width) for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
        qrImage?.let(root::removeView)
        qrImage = ImageView(this).apply {
            setImageBitmap(bitmap)
            contentDescription = "QR Code de vinculação do Droid Zap. Use o WhatsApp principal para escanear."
            adjustViewBounds = true
        }
        root.addView(qrImage, 2)
    }

    private fun showSettings() {
        onHomeScreen = false
        base("Configurações")
        fun option(label: String, checked: Boolean, update: (Boolean) -> Unit) = CheckBox(this).apply {
            text = label; isChecked = checked; contentDescription = label
            setOnCheckedChangeListener { _, value -> update(value) }
        }
        root.addView(option("Falar quando alguém estiver digitando ou gravando", prefs.spokenAlerts) { prefs.spokenAlerts = it })
        root.addView(option("Vibrar nos avisos", prefs.vibration) { prefs.vibration = it })
        root.addView(option("Som ao digitar", prefs.keyboardSound) { prefs.keyboardSound = it })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ToneEngine.Style.entries.map { it.label })
            setSelection(ToneEngine.Style.entries.indexOf(prefs.style)); contentDescription = "Categoria de som"
        }
        root.addView(spinner)
        root.addView(button("Ouvir amostra") {
            prefs.style = ToneEngine.Style.entries[spinner.selectedItemPosition]
            tones.play(prefs.style); announce("Amostra ${prefs.style.label}")
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun announce(message: String) {
        window.decorView.announceForAccessibility(message)
        if (prefs.spokenAlerts) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "droid_zap_status")
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR") }
    override fun onDestroy() { voiceRecorder.cancel(); protocol.disconnect(); tts?.shutdown(); super.onDestroy() }
}
