package br.com.droidzap

import android.content.Context
import android.media.MediaRecorder
import java.io.File

/** Records speech as WhatsApp-compatible Ogg/Opus in app-private storage. */
class VoiceRecorder(private val context: Context) {
    data class Result(val file: File, val durationSeconds: Long)

    private var recorder: MediaRecorder? = null
    private var output: File? = null
    private var startedAt = 0L

    @Suppress("DEPRECATION")
    fun start() {
        check(recorder == null) { "Já existe uma gravação em andamento" }
        val file = File(context.cacheDir, "voice-${System.currentTimeMillis()}.ogg")
        val next = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
            setOutputFormat(MediaRecorder.OutputFormat.OGG)
            setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
            setAudioChannels(1)
            setAudioSamplingRate(48_000)
            setAudioEncodingBitRate(48_000)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        output = file
        recorder = next
        startedAt = System.currentTimeMillis()
    }

    fun stop(): Result {
        val active = recorder ?: error("Nenhuma gravação em andamento")
        val file = output ?: error("Arquivo de gravação ausente")
        val duration = ((System.currentTimeMillis() - startedAt) / 1000).coerceAtLeast(1)
        try { active.stop() } finally { active.release(); recorder = null; output = null }
        check(file.length() > 0) { "Não foi possível capturar a voz" }
        return Result(file, duration)
    }

    fun cancel() {
        recorder?.runCatching { stop() }
        recorder?.release()
        recorder = null
        output?.delete()
        output = null
    }
}
