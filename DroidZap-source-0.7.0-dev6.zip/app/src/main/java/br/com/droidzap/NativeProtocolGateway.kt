package br.com.droidzap

import android.content.Context
import bridge.Engine
import bridge.Listener
import bridge.Bridge

class NativeProtocolGateway(context: Context) : ProtocolGateway, Listener {
    private var observer: ((ProtocolGateway.State) -> Unit)? = null
    private var messageObserver: ((String, String, String, Long) -> Unit)? = null
    private var activityObserver: ((String, String, String, Boolean) -> Unit)? = null
    private var state: ProtocolGateway.State = ProtocolGateway.State.Disconnected
    private val engine: Engine = Bridge.newEngine(this)

    init {
        runCatching {
            engine.start(context.getDatabasePath("droidzap-session.db").absolutePath)
        }.onFailure { update(ProtocolGateway.State.Failed("Falha ao abrir a sessão: ${it.message}")) }
    }

    override fun currentState() = state

    override fun requestQrPairing(onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestQR() }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar QR Code")) }
    }

    override fun requestPhonePairing(phoneE164: String, onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestPhone(phoneE164) }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar código")) }
    }

    override fun onState(protocolState: String?, detail: String?) {
        when (protocolState) {
            "connecting" -> update(ProtocolGateway.State.Connecting)
            "connected" -> update(ProtocolGateway.State.Connected)
            "disconnected" -> update(ProtocolGateway.State.Disconnected)
            "error" -> update(ProtocolGateway.State.Failed(detail ?: "Erro de conexão"))
        }
    }

    override fun onQRCode(payload: String?, validForSeconds: Long) {
        if (payload != null) update(ProtocolGateway.State.QrReady(payload, System.currentTimeMillis() + validForSeconds * 1000))
    }

    override fun onPairCode(code: String?) {
        if (code != null) update(ProtocolGateway.State.PairCodeReady(code))
    }

    override fun sendText(chatJid: String, text: String) = engine.sendText(chatJid, text)

    override fun sendVoice(chatJid: String, filePath: String, durationSeconds: Long) =
        engine.sendVoice(chatJid, filePath, durationSeconds)

    override fun observeMessages(observer: (String, String, String, Long) -> Unit) {
        messageObserver = observer
    }

    override fun observeChatActivity(observer: (String, String, String, Boolean) -> Unit) {
        activityObserver = observer
    }

    override fun onMessage(chatJID: String?, senderJID: String?, text: String?, timestamp: Long) {
        messageObserver?.invoke(chatJID.orEmpty(), senderJID.orEmpty(), text.orEmpty(), timestamp)
    }

    override fun onChatActivity(chatJID: String?, senderJID: String?, activity: String?, active: Boolean) {
        activityObserver?.invoke(chatJID.orEmpty(), senderJID.orEmpty(), activity.orEmpty(), active)
    }

    private fun update(next: ProtocolGateway.State) {
        state = next
        observer?.invoke(next)
    }

    override fun disconnect() { engine.stop() }
}
