package br.com.droidzap

import android.content.Context

class Preferences(context: Context) {
    private val store = context.getSharedPreferences("droid_zap", Context.MODE_PRIVATE)
    var spokenAlerts: Boolean
        get() = store.getBoolean("spoken", true)
        set(value) = store.edit().putBoolean("spoken", value).apply()
    var vibration: Boolean
        get() = store.getBoolean("vibration", true)
        set(value) = store.edit().putBoolean("vibration", value).apply()
    var keyboardSound: Boolean
        get() = store.getBoolean("keyboard", false)
        set(value) = store.edit().putBoolean("keyboard", value).apply()
    var style: ToneEngine.Style
        get() = runCatching { ToneEngine.Style.valueOf(store.getString("style", "IPHONE_INSPIRED")!!) }
            .getOrDefault(ToneEngine.Style.IPHONE_INSPIRED)
        set(value) = store.edit().putString("style", value.name).apply()
}
