# Droid Zap

Protótipo Android nativo e acessível, baseado nos eventos e pacotes de sons do
ZappInfinit. O aplicativo abre o WhatsApp Web como dispositivo vinculado e não
precisa de um servidor próprio em computador ou VPS.

## Estado do projeto

- Nome e pacote: `Droid Zap` / `br.com.droidzap`
- Versão: 0.6.0
- Compatibilidade: Android 11 (API 30) até Android 16 (API 36)
- Interface compatível com TalkBack e navegação por foco
- Avisos de digitação e gravação por fala, vibração e som
- Cliques de teclado opcionais
- 48 combinações originais de alerta: seis variações em oito categorias
- Categorias originais inspiradas em iPhone, Samsung, Xiaomi e Motorola, sem copiar seus áudios
- Quatro categorias exclusivas Droid Zap: Cristal, Suave, Pulso e Minimalista
- Botão **Procurar atualização** e verificação automática ao iniciar
- Captura de voz em 48 kHz com redução de ruído, eco e ganho automático quando suportado
- Permissões WebRTC para chamadas de voz e vídeo quando o WhatsApp Web oferecer o recurso
- Pareamento oficial por QR ou telefone, conforme as opções exibidas pelo WhatsApp Web
- Nenhum áudio proprietário de fabricante é redistribuído

## Compilar

Abra esta pasta no Android Studio (JDK 17) e execute **Run**, ou use o Gradle
8.11.1:

```text
gradle assembleDebug
```

O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Gerar o APK pelo GitHub

1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta.
2. Abra a aba **Actions** e escolha **Gerar APK do Droid Zap**.
3. Ao final, baixe o artefato **DroidZap-debug**.
4. Quando publicar uma GitHub Release, o fluxo também anexa
   `DroidZap-debug.apk` à versão.

O APK `debug` serve para testes. Antes da distribuição pública é necessário
configurar uma chave de assinatura de produção nos Secrets do GitHub. Não envie
o arquivo da chave nem suas senhas ao repositório.

## Atualizações

O aplicativo usa o mecanismo oficial de atualizações da Google Play. Para o
botão encontrar versões novas, publique o Droid Zap na Play Store sempre com o
mesmo `applicationId` (`br.com.droidzap`), a mesma chave de assinatura e um
`versionCode` maior. Ao abrir o aplicativo ele também faz uma verificação sem
interromper o usuário quando não há versão nova.

A atualização totalmente automática é uma configuração da Play Store e do
aparelho. O Android não permite que um APK comum substitua silenciosamente a si
mesmo; quando necessário, o sistema exibe a confirmação segura ao usuário.

## Limitações importantes

O WhatsApp não oferece uma API oficial para criar um cliente pessoal completo.
Esta versão usa a página WhatsApp Web como dispositivo vinculado. A detecção de
“digitando” e “gravando áudio” observa apenas textos de estado visíveis na página
e pode precisar de ajustes quando a página mudar. O aplicativo não usa Serviço
de Acessibilidade para ler ou controlar outros aplicativos.

O QR é gerado e renovado pela própria página do WhatsApp. O vínculo por telefone
aparece quando esse método é disponibilizado pela Meta para a conta. O Droid Zap
não gera, guarda nem envia códigos de pareamento. Chamadas dependem de o WhatsApp
Web habilitar WebRTC no Android WebView e podem não estar disponíveis em todos os
aparelhos ou contas; isso não equivale ao protocolo nativo fechado do WhatsApp.
