plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.droidzap"
    compileSdk = 36

    defaultConfig {
        applicationId = "br.com.droidzap"
        minSdk = 30
        targetSdk = 36
        versionCode = 6
        versionName = "0.6.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.play:app-update-ktx:2.1.0")
}
