package br.com.droidzap

import android.os.Bundle
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var prefs: Preferences
    private val tones = ToneEngine()
    private lateinit var protocol: ProtocolGateway
    private var tts: TextToSpeech? = null
    private var onHomeScreen = true

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        prefs = Preferences(this)
        protocol = NativeProtocolGateway(this)
        tts = TextToSpeech(this, this)
        onBackPressedDispatcher.addCallback(this) { if (onHomeScreen) finish() else showHome() }
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
            addView(TextView(this@MainActivity).apply {
                text = title; textSize = 24f; contentDescription = title
                isAccessibilityHeading = true
            })
        }
        setContentView(root)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; contentDescription = label; setOnClickListener { action() }
    }

    private fun showHome() {
        onHomeScreen = true
        base("Droid Zap 0.7")
        root.addView(TextView(this).apply {
            text = "Cliente Android nativo experimental, sem chamadas"; contentDescription = text
        })
        root.addView(button("Parear aparelho") { showPairing() })
        root.addView(button("Conversas") { announce("Conecte uma conta antes de abrir as conversas") })
        root.addView(button("Configurações de acessibilidade e sons") { showSettings() })
    }

    private fun showPairing() {
        onHomeScreen = false
        base("Parear aparelho")
        val status = TextView(this).apply {
            text = "Escolha pareamento por QR Code ou telefone"; contentDescription = text
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        }
        root.addView(status)
        root.addView(button("Gerar QR Code") {
            status.text = "Solicitando novo QR Code"
            protocol.requestQrPairing { state -> runOnUiThread { renderProtocolState(state, status) } }
        })
        val phone = EditText(this).apply {
            hint = "Número com país e DDD, por exemplo 5511999999999"
            contentDescription = "Número de telefone com código do país e DDD"
            inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(phone)
        root.addView(button("Gerar código por telefone") {
            val normalized = phone.text.toString().filter(Char::isDigit)
            if (normalized.length < 10) announce("Digite um número válido com código do país e DDD")
            else protocol.requestPhonePairing(normalized) { state ->
                runOnUiThread { renderProtocolState(state, status) }
            }
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun renderProtocolState(state: ProtocolGateway.State, status: TextView) {
        val message = when (state) {
            ProtocolGateway.State.Disconnected -> "Desconectado"
            ProtocolGateway.State.Connecting -> "Conectando"
            is ProtocolGateway.State.QrReady -> {
                showQrCode(state.payload)
                "Novo QR Code disponível"
            }
            is ProtocolGateway.State.PairCodeReady -> "Código de pareamento: ${state.code}"
            ProtocolGateway.State.Connected -> "Conta conectada"
            is ProtocolGateway.State.Failed -> state.accessibleMessage
        }
        status.text = message
        announce(message)
    }

    private fun showQrCode(payload: String) {
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 720, 720)
        val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.RGB_565)
        for (x in 0 until matrix.width) for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
        root.addView(ImageView(this).apply {
            setImageBitmap(bitmap)
            contentDescription = "QR Code de vinculação do Droid Zap. Use o WhatsApp principal para escanear."
            adjustViewBounds = true
        }, 2)
    }

    private fun showSettings() {
        onHomeScreen = false
        base("Configurações")
        fun option(label: String, checked: Boolean, update: (Boolean) -> Unit) = CheckBox(this).apply {
            text = label; isChecked = checked; contentDescription = label
            setOnCheckedChangeListener { _, value -> update(value) }
        }
        root.addView(option("Falar quando alguém estiver digitando ou gravando", prefs.spokenAlerts) { prefs.spokenAlerts = it })
        root.addView(option("Vibrar nos avisos", prefs.vibration) { prefs.vibration = it })
        root.addView(option("Som ao digitar", prefs.keyboardSound) { prefs.keyboardSound = it })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, ToneEngine.Style.entries.map { it.label })
            setSelection(ToneEngine.Style.entries.indexOf(prefs.style)); contentDescription = "Categoria de som"
        }
        root.addView(spinner)
        root.addView(button("Ouvir amostra") {
            prefs.style = ToneEngine.Style.entries[spinner.selectedItemPosition]
            tones.play(prefs.style); announce("Amostra ${prefs.style.label}")
        })
        root.addView(button("Voltar") { showHome() })
    }

    private fun announce(message: String) {
        window.decorView.announceForAccessibility(message)
        if (prefs.spokenAlerts) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "droid_zap_status")
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR") }
    override fun onDestroy() { protocol.disconnect(); tts?.shutdown(); super.onDestroy() }
}
