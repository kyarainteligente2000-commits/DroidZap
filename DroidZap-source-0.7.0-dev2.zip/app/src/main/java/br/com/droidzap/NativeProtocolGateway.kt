package br.com.droidzap

import android.content.Context
import bridge.Engine
import bridge.Listener
import bridge.Bridge

class NativeProtocolGateway(context: Context) : ProtocolGateway, Listener {
    private var observer: ((ProtocolGateway.State) -> Unit)? = null
    private var state: ProtocolGateway.State = ProtocolGateway.State.Disconnected
    private val engine: Engine = Bridge.newEngine(this)

    init {
        runCatching {
            engine.start(context.getDatabasePath("droidzap-session.db").absolutePath)
        }.onFailure { update(ProtocolGateway.State.Failed("Falha ao abrir a sessão: ${it.message}")) }
    }

    override fun currentState() = state

    override fun requestQrPairing(onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestQR() }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar QR Code")) }
    }

    override fun requestPhonePairing(phoneE164: String, onState: (ProtocolGateway.State) -> Unit) {
        observer = onState
        update(ProtocolGateway.State.Connecting)
        runCatching { engine.requestPhone(phoneE164) }
            .onFailure { update(ProtocolGateway.State.Failed(it.message ?: "Falha ao solicitar código")) }
    }

    override fun onState(protocolState: String?, detail: String?) {
        when (protocolState) {
            "connecting" -> update(ProtocolGateway.State.Connecting)
            "connected" -> update(ProtocolGateway.State.Connected)
            "disconnected" -> update(ProtocolGateway.State.Disconnected)
            "error" -> update(ProtocolGateway.State.Failed(detail ?: "Erro de conexão"))
        }
    }

    override fun onQRCode(payload: String?, validForSeconds: Long) {
        if (payload != null) update(ProtocolGateway.State.QrReady(payload, System.currentTimeMillis() + validForSeconds * 1000))
    }

    override fun onPairCode(code: String?) {
        if (code != null) update(ProtocolGateway.State.PairCodeReady(code))
    }

    override fun onMessage(chatJID: String?, senderJID: String?, text: String?, timestamp: Long) = Unit

    private fun update(next: ProtocolGateway.State) {
        state = next
        observer?.invoke(next)
    }

    override fun disconnect() { engine.stop() }
}
