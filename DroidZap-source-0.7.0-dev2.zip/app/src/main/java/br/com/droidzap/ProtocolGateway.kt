package br.com.droidzap

/** Boundary between the native Android UI and the embedded protocol runtime. */
interface ProtocolGateway {
    sealed interface State {
        data object Disconnected : State
        data object Connecting : State
        data class QrReady(val payload: String, val expiresAtMillis: Long) : State
        data class PairCodeReady(val code: String) : State
        data object Connected : State
        data class Failed(val accessibleMessage: String) : State
    }

    fun currentState(): State
    fun requestQrPairing(onState: (State) -> Unit)
    fun requestPhonePairing(phoneE164: String, onState: (State) -> Unit)
    fun disconnect()
}

/** Safe development implementation until the native protocol AAR is linked. */
class PendingProtocolGateway : ProtocolGateway {
    override fun currentState(): ProtocolGateway.State = ProtocolGateway.State.Disconnected
    override fun requestQrPairing(onState: (ProtocolGateway.State) -> Unit) {
        onState(ProtocolGateway.State.Failed("O módulo de pareamento ainda está sendo instalado nesta versão de desenvolvimento."))
    }
    override fun requestPhonePairing(phoneE164: String, onState: (ProtocolGateway.State) -> Unit) {
        onState(ProtocolGateway.State.Failed("O módulo de pareamento por telefone ainda está sendo instalado nesta versão de desenvolvimento."))
    }
    override fun disconnect() = Unit
}
