# Droid Zap

Cliente Android nativo, experimental e acessível para dispositivo vinculado.
Não usa WebView, WhatsApp Web, computador, VPS nem chamadas.

## Estado da versão 0.7.0-rc3

- Android 11 (API 30) até Android 16 (API 36)
- Protocolo vinculado incorporado com banco de sessão privado
- Pareamento por QR renovável ou código por número de telefone
- Código de pareamento focável, falado dígito por dígito e copiável
- Nova conversa com contatos sincronizados pelo catálogo do Android/Google
- Envio e recebimento de texto
- Gravação e envio de voz em Ogg/Opus, mono, 48 kHz
- Sons originais distintos ao iniciar e finalizar uma gravação
- Avisos acessíveis de conexão, digitação e gravação
- Relatório local de diagnóstico sem armazenar QR, código ou texto das mensagens
- 48 combinações de alertas originais em oito categorias
- Atualizador por GitHub Releases, com confirmação segura do Android
- APK release assinada por uma chave permanente armazenada em GitHub Secrets

As categorias inspiradas em fabricantes são composições originais. Nenhum áudio
proprietário de Apple, Samsung, Xiaomi ou Motorola é redistribuído.

## Compilação

O workflow extrai a fonte versionada, gera a biblioteca Android do protocolo Go
com `gomobile`, executa o lint, compila a APK release, assina e confere o
certificado. A chave privada e as senhas nunca fazem parte do repositório.

## Atualizações

O botão **Procurar atualização** consulta as versões publicadas neste
repositório. Quando encontra uma versão superior, baixa a APK e abre o
instalador. O Android exige confirmação do usuário e todas as versões precisam
usar a mesma chave e um `versionCode` crescente.

## Limitações e risco

Esta integração não é oficial e pode deixar de funcionar quando o serviço
alterar o protocolo. Há risco de desconexão ou restrição da conta. A RC precisa
ser validada em um aparelho Android real antes de ser publicada como estável.
